﻿import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
  CartesianGrid,
} from "recharts";
import {
  Activity,
  AlertTriangle,
  Warehouse,
  MessageCircle,
  RefreshCw,
  MapPin,
  Database,
  Send,
  ShieldCheck,
  ShoppingBasket,
  LineChart,
  ScrollText,
  Sparkles,
  Play,
  SlidersHorizontal,
  Factory,
  Store,
  Bot,
  Route,
  Radio,
  RotateCcw,
  Truck,
  Boxes,
  Users,
  LogOut,
  KeyRound,
  UserCheck,
  ServerCog,
} from "lucide-react";
import "./style.css";
const API = (
  import.meta.env.VITE_API_URL || "http://localhost:8000/api"
).replace(/\/$/, "");
const fmt = (n) =>
  new Intl.NumberFormat("en-IN", { maximumFractionDigits: 0 }).format(n || 0);
const formatDuration = (minutes) => {
  const value = Number(minutes) || 0;
  if (value >= 1440) {
    const days = value / 1440;
    return `${days >= 10 ? Math.round(days) : days.toFixed(1).replace(/\.0$/, "")} days`;
  }
  if (value >= 60) return `${Math.round(value / 60)} hr`;
  return `${Math.round(value)} min`;
};
const REQUEST_TIMEOUT_MS = 20000;
const request = async (path, options = {}) => {
  const controller = new AbortController();
  const timer = window.setTimeout(() => controller.abort(), REQUEST_TIMEOUT_MS);
  try {
    const response = await fetch(`${API}/${path}`, {
      ...options,
      signal: controller.signal,
    });
    if (!response.ok) throw Error(`${path} (${response.status})`);
    return await response.json();
  } catch (error) {
    if (error.name === "AbortError") throw Error(`${path} timed out`);
    throw error;
  } finally {
    window.clearTimeout(timer);
  }
};
const get = (path) => request(path);
const Badge = ({ value }) => (
  <span
    className={`badge ${
      String(value || "low")
        .toLowerCase()
        .split(/[ .]/)[0]
    }`}
  >
    {value}
  </span>
);
const DEMO_USERS = {
  user: {
    email: "user@supplymuse.io",
    password: "demo123",
    label: "User",
    name: "Alex Morgan",
  },
  admin: {
    email: "admin@supplymuse.io",
    password: "admin123",
    label: "Admin",
    name: "Priya Shah",
  },
};
const makeMessage = (role, text, extra = {}) => ({
  id: `${role}-${Date.now()}-${Math.random().toString(16).slice(2)}`,
  role,
  text,
  ...extra,
});
const formatStructuredValue = (value, maxItems = 4) => {
  if (value === null || value === undefined) return "—";
  if (
    typeof value === "string" ||
    typeof value === "number" ||
    typeof value === "boolean"
  )
    return String(value);
  if (Array.isArray(value))
    return value
      .slice(0, maxItems)
      .map((item) => formatStructuredValue(item, 2))
      .join(", ");
  if (typeof value === "object")
    return Object.entries(value)
      .slice(0, 3)
      .map(([key, entry]) => `${key}: ${formatStructuredValue(entry, 2)}`)
      .join(" • ");
  return String(value);
};
const renderInlineMarkdown = (text, key) =>
  String(text)
    .split(/(\*\*[^*]+\*\*|\*[^*]+\*|\x60[^\x60]+\x60)/g)
    .filter(Boolean)
    .map((part, index) =>
      part.startsWith("**") ? (
        <strong key={key + "-bold-" + index}>{part.slice(2, -2)}</strong>
      ) : part.startsWith("*") ? (
        <em key={key + "-em-" + index}>{part.slice(1, -1)}</em>
      ) : part.startsWith("\x60") ? (
        <code key={key + "-code-" + index}>{part.slice(1, -1)}</code>
      ) : (
        part
      ),
    );
function MessageText({ text }) {
  const lines = String(text || "")
    .replace(/\r/g, "")
    .split("\n");
  return (
    <div className="message-body markdown-message">
      {lines.map((line, index) => {
        const heading = line.match(/^\s{0,3}#{1,6}\s+(.+)$/);
        const bullet = line.match(/^\s*(?:[-+*]|\d+\.)\s+(.+)$/);
        if (heading)
          return (
            <strong className="message-heading" key={index}>
              {renderInlineMarkdown(heading[1], index)}
            </strong>
          );
        if (bullet)
          return (
            <div className="message-list-item" key={index}>
              <span>•</span>
              <div>{renderInlineMarkdown(bullet[1], index)}</div>
            </div>
          );
        return line.trim() ? (
          <p key={index}>{renderInlineMarkdown(line, index)}</p>
        ) : (
          <div className="message-spacer" key={index} />
        );
      })}
    </div>
  );
}
class AppErrorBoundary extends React.Component {
  constructor(props) {
    super(props);
    this.state = { error: null };
  }
  static getDerivedStateFromError(error) {
    return { error };
  }
  componentDidCatch(error, info) {
    console.error("SupplyMuse UI error", error, info);
  }
  render() {
    if (this.state.error)
      return (
        <div className="fatal-error">
          <h1>Something went wrong in the dashboard.</h1>
          <p>
            Reload the page to restore the workspace. The browser console has
            the error details for troubleshooting.
          </p>
          <button className="primary" onClick={() => window.location.reload()}>
            Reload dashboard
          </button>
        </div>
      );
    return this.props.children;
  }
}

function App() {
  const [auth, setAuth] = useState(() => {
    try {
      return (
        JSON.parse(localStorage.getItem("supplymuse-auth") || "null") || {
          authenticated: false,
          role: "user",
          name: "Guest",
        }
      );
    } catch {
      return { authenticated: false, role: "user", name: "Guest" };
    }
  });
  const [tab, setTab] = useState("Overview"),
    [data, setData] = useState({}),
    [busy, setBusy] = useState(true),
    [error, setError] = useState(""),
    [q, setQ] = useState(""),
    [chat, setChat] = useState([]),
    [asking, setAsking] = useState(false),
    [simulation, setSimulation] = useState(null),
    [loginData, setLoginData] = useState({ email: "", password: "" }),
    [loginError, setLoginError] = useState(""),
    [loginMode, setLoginMode] = useState("user");
  const userNav = [
    ["Overview", Activity],
    ["Suppliers", Truck],
    ["Delivery Risks", AlertTriangle],
    ["Inventory", Warehouse],
    ["Forecasts", LineChart],
    ["Anomalies", AlertTriangle],
    ["AI Assistant", MessageCircle],
    ["Project Evaluation", ScrollText],
    ["Risk Report", ShieldCheck],
    ["Supply Simulation", Route],
    ["Agent Studio", Bot],
  ];
  const adminNav = [
    ...userNav,
    ["User Management", Users],
    ["Data Quality", Database],
    ["Agent Monitoring", Radio],
    ["Audit & Observability", ScrollText],
    ["System Settings", SlidersHorizontal],
  ];
  const nav = auth.role === "admin" ? adminNav : userNav;
  const isDashboardReady = Boolean(data.summary && data.summary.unique_orders);
  const load = async () => {
    setBusy(true);
    setError("");
    try {
      const names = [
        "summary",
        "trends",
        "risks?limit=300",
        "inventory?limit=800",
        "stock-summary",
        "suppliers",
        "categories",
        "cities",
        "quality",
        "forecast",
        "anomalies",
        "risk-report",
        "observability/metrics",
        "audit/traces?limit=25",
        "explainability",
        "llm/status",
        "simulation",
        "evaluation",
      ];
      const results = await Promise.allSettled(names.map(get));
      const next = {};
      const failed = [];
      results.forEach((result, index) => {
        const key = names[index].split("?")[0];
        if (result.status === "fulfilled") next[key] = result.value;
        else failed.push(key);
      });
      if (!next.summary) {
        throw new Error("The backend did not return dashboard data");
      }
      setData((previous) => ({ ...previous, ...next }));
      setSimulation((current) => current || next.simulation || null);
      if (failed.length)
        setError(
          `Some dashboard signals are unavailable (${failed.join(", ")}). You can keep working and refresh later.`,
        );
    } catch (e) {
      setError(
        `The supply-chain service is unavailable: ${e.message}. Start the FastAPI backend on port 8000, then retry.`,
      );
    } finally {
      setBusy(false);
    }
  };
  useEffect(() => {
    if (auth.authenticated) {
      load();
    }
  }, [auth.authenticated]);
  useEffect(() => {
    if (auth.authenticated)
      localStorage.setItem("supplymuse-auth", JSON.stringify(auth));
  }, [auth]);
  const ask = async (text = q) => {
    const question = String(text || "").trim();
    if (!question || asking) return;
    setChat((c) => [...c, makeMessage("user", question)]);
    setQ("");
    setAsking(true);
    try {
      const a = await request("assistant", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question }),
      });
      setChat((c) => [
        ...c,
        makeMessage(
          "assistant",
          typeof a.answer === "string" && a.answer.trim()
            ? a.answer
            : "The assistant returned no readable answer.",
          {
            evidence: Array.isArray(a.evidence) ? a.evidence : [],
            trace: Array.isArray(a.agent_trace) ? a.agent_trace : [],
            audit: a.audit && typeof a.audit === "object" ? a.audit : null,
            note: typeof a.note === "string" ? a.note : "",
            routed_agents: Array.isArray(a.routed_agents)
              ? a.routed_agents
              : [],
          },
        ),
      ]);
    } catch (e) {
      setChat((c) => [
        ...c,
        makeMessage(
          "assistant",
          `I could not complete that request. ${e.message}. Please try again.`,
        ),
      ]);
    } finally {
      setAsking(false);
    }
  };
  const runSimulation = async (params) => {
    try {
      const search = new URLSearchParams(params);
      setSimulation(await get(`simulation?${search}`));
    } catch (e) {
      setError(`Simulation failed: ${e.message}`);
    }
  };
  const s = data.summary || {};
  const handleLogin = (e) => {
    e.preventDefault();
    const enteredEmail = (loginData.email || "").trim().toLowerCase();
    const enteredPassword = loginData.password || "";
    if (!enteredEmail || !enteredPassword) {
      setLoginError("Enter your email and password.");
      return;
    }
    const match = Object.entries(DEMO_USERS).find(
      ([, user]) =>
        user.email === enteredEmail && user.password === enteredPassword,
    );
    if (match) {
      const [role, profile] = match;
      setAuth({ authenticated: true, role: role, name: profile.name });
      setLoginError("");
      setTab("Overview");
    } else {
      setLoginError("Incorrect email or password.");
    }
  };
  const logout = () => {
    setAuth({ authenticated: false, role: "user", name: "Guest" });
    localStorage.removeItem("supplymuse-auth");
    setLoginData({ email: "", password: "" });
    setTab("Overview");
  };
  if (!auth.authenticated) {
    return (
      <div className="login-shell">
        <div className="login-panel">
          <div className="login-brand-panel">
            <div className="login-brand">
              <div className="login-mark" aria-label="SupplyMuse logo">
                <svg viewBox="0 0 64 64" aria-hidden="true">
                  <path
                    d="M18 16h20c7.7 0 14 6.3 14 14v8c0 7.7-6.3 14-14 14H18V16Z"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.8"
                    strokeLinejoin="round"
                  />
                  <path
                    d="M18 26h20M18 38h14"
                    stroke="currentColor"
                    strokeWidth="2.8"
                    strokeLinecap="round"
                  />
                  <path
                    d="M42 20l8-8M42 20l8 8M48 14l0 12M18 16l-8 0 0 32 8 0"
                    fill="none"
                    stroke="currentColor"
                    strokeWidth="2.8"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  />
                  <circle cx="49" cy="18" r="3.2" fill="currentColor" />
                  <circle cx="49" cy="46" r="3.2" fill="currentColor" />
                  <circle cx="19" cy="32" r="3.2" fill="currentColor" />
                </svg>
              </div>
              <div className="brand-wordmark login-wordmark">
                <span className="brand-supply">SUPPLY</span>
                <span className="brand-muse">MUSE</span>
              </div>
            </div>
            <p className="login-tagline">
              AI-Powered Supply Chain Risk Intelligence
            </p>
            <h1>
              Operate resilient supply networks with evidence-led decisions.
            </h1>
            <ul className="login-feature-list">
              <li>Supplier performance intelligence</li>
              <li>Delivery and inventory risk mapping</li>
              <li>Forecast-aware operational response</li>
            </ul>
          </div>
          <div className="login-form-wrap">
            <div className="login-card-header">
              <span className="eyebrow eyebrow-brown">Secure access</span>
              <h2>Welcome back</h2>
            </div>
            <div className="access-switch" aria-label="Access level">
              <button
                type="button"
                className={`access-option ${loginMode === "user" ? "active" : ""}`}
                onClick={() => setLoginMode("user")}
              >
                User access
              </button>
              <button
                type="button"
                className={`access-option ${loginMode === "admin" ? "active" : ""}`}
                onClick={() => setLoginMode("admin")}
              >
                Admin access
              </button>
            </div>
            <form className="auth-form" onSubmit={handleLogin}>
              <label>
                Email
                <input
                  value={loginData.email}
                  onChange={(e) =>
                    setLoginData({ ...loginData, email: e.target.value })
                  }
                  type="email"
                  placeholder="you@company.com"
                />
              </label>
              <label>
                Password
                <input
                  value={loginData.password}
                  onChange={(e) =>
                    setLoginData({ ...loginData, password: e.target.value })
                  }
                  type="password"
                  placeholder="••••••••"
                />
              </label>
              <div className="remember-row">
                <label className="checkbox-row">
                  <input type="checkbox" defaultChecked />
                  <span>Remember me</span>
                </label>
                <button type="button" className="text-link">
                  Forgot password?
                </button>
              </div>
              {loginError && <div className="auth-error">{loginError}</div>}
              <button type="submit" className="primary login-btn">
                {loginMode === "admin"
                  ? "Enter admin workspace"
                  : "Access dashboard"}
              </button>
            </form>
            <div className="login-meta">
              <span>Protected by audit-grade controls</span>
              <span>Role is verified by credentials</span>
            </div>
          </div>
        </div>
      </div>
    );
  }
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <div className="brand">
          <div className="muse-mark">
            <svg viewBox="0 0 36 36" aria-hidden="true">
              <path
                d="M10 6.5c4.2-2.7 10.8-2.7 15 0 3.5 2.4 5 6.7 3.5 10.4-1.1 2.7-3.9 4.9-7 5.7l-2.2.6c-3.4.9-6.2 3.4-7.4 6.6-.8 2.1-.3 4.2 1.5 5.8 2.2 2 5.4 2.7 8.3 1.8"
                fill="none"
                stroke="currentColor"
                strokeWidth="2.2"
                strokeLinecap="round"
                strokeLinejoin="round"
              />
              <circle cx="24" cy="10" r="2.2" fill="currentColor" />
              <circle cx="12" cy="26" r="2.2" fill="currentColor" />
            </svg>
          </div>
          <div className="brand-wordmark">
            <span className="brand-supply">SUPPLY</span>
            <span className="brand-muse">MUSE</span>
            <small>DECISION INTELLIGENCE</small>
          </div>
        </div>
        <div className="section-label">
          {auth.role === "admin" ? "ADMIN COMMAND CENTER" : "COMMAND CENTER"}
        </div>
        {nav.map(([name, Icon]) => (
          <button
            className={`nav ${tab === name ? "active" : ""}`}
            onClick={() => setTab(name)}
            key={name}
          >
            <Icon size={17} />
            <span>{name}</span>
          </button>
        ))}
        <div className="sidebottom">
          <span className="live-dot" />
          {auth.role === "admin" ? "Admin terminal online" : "Live supply twin"}
          <small>
            {auth.role === "admin"
              ? "Policy + execution + observability"
              : "6 cities · 35 suppliers · auditable"}
          </small>
          <button className="refresh side-refresh" onClick={load}>
            <RefreshCw size={14} />
            Refresh
          </button>
        </div>
      </aside>
      <main className="main">
        <header>
          <div>
            <div className="eyebrow">
              SUPPLYMUSE / {auth.role === "admin" ? "ADMIN OPS" : "USER OPS"}
            </div>
            <h1>{tab}</h1>
            <p>From signal to decision, with explainable risk intelligence.</p>
          </div>
          <div className="header-actions">
            <div className="user-pill">
              <UserCheck size={15} /> {auth.name}
            </div>
            <button className="refresh" onClick={load}>
              <RefreshCw size={15} />
              Refresh data
            </button>
            <button className="ghost-btn" onClick={logout}>
              <LogOut size={15} />
              Logout
            </button>
          </div>
        </header>
        {error && <div className="error">{error}</div>}
        {busy && !isDashboardReady ? (
          <div className="loading">Loading live supply signals...</div>
        ) : (
          <>
            {tab === "Overview" && (
              <Overview
                s={s}
                stock={data["stock-summary"] || {}}
                trends={data.trends || []}
                risks={data.risks || []}
                simulation={simulation}
              />
            )}{" "}
            {tab === "Supply Simulation" && (
              <Simulation
                simulation={simulation}
                suppliers={data.suppliers || []}
                onRun={runSimulation}
              />
            )}{" "}
            {tab === "Agent Studio" && (
              <AgentStudio
                latest={chat[chat.length - 1]}
                provider={data["llm/status"]}
              />
            )}{" "}
            {tab === "Delivery Risks" && (
              <TablePanel
                title="Delivery risk register"
                sub="Prioritized delivery rows with transparent severity and anomaly signals."
              >
                <RiskTable rows={data.risks || []} />
              </TablePanel>
            )}{" "}
            {tab === "Inventory" && (
              <Inventory
                rows={data.inventory || []}
                stock={data["stock-summary"] || {}}
              />
            )}{" "}
            {tab === "Forecasts" && <Forecast forecast={data.forecast || {}} />}{" "}
            {tab === "Anomalies" && (
              <TablePanel
                title="Operational anomalies"
                sub="Lead-time, volume, and inventory shortfall alerts."
              >
                <AnomalyTable rows={data.anomalies || []} />
              </TablePanel>
            )}{" "}
            {tab === "Project Evaluation" && (
              <EvaluationPanel report={data.evaluation || {}} />
            )}{" "}
            {tab === "Risk Report" && (
              <RiskReport report={data["risk-report"] || {}} />
            )}{" "}
            {tab === "Suppliers" && (
              <TablePanel
                title="Supplier scorecards"
                sub="Reliability, lead-time variability, and weighted risk."
              >
                <SupplierTable rows={data.suppliers || []} />
              </TablePanel>
            )}{" "}
            {tab === "AI Assistant" && (
              <Assistant
                chat={chat}
                q={q}
                setQ={setQ}
                ask={ask}
                asking={asking}
                provider={data["llm/status"]}
              />
            )}{" "}
            {tab === "User Management" && <UserManagementPanel />}{" "}
            {tab === "Agent Monitoring" && (
              <AgentMonitoringPanel provider={data["llm/status"]} />
            )}{" "}
            {tab === "Audit & Observability" && (
              <Audit
                metrics={data["observability/metrics"] || {}}
                traces={data["audit/traces"]?.traces || []}
                explain={data.explainability || {}}
              />
            )}{" "}
            {tab === "Data Quality" && <Quality quality={data.quality || {}} />}{" "}
            {tab === "System Settings" && <SystemSettingsPanel />}
          </>
        )}
      </main>
    </div>
  );
}

function UserManagementPanel() {
  return (
    <div className="admin-grid">
      <div className="mini-card">
        <div className="mini-card-head">
          <Users size={16} /> Users
        </div>
        <h3>214 active seats</h3>
        <p>Operations, planning, supplier managers, and analysts.</p>
      </div>
      <div className="mini-card">
        <div className="mini-card-head">
          <ShieldCheck size={16} /> Roles
        </div>
        <h3>3 role groups</h3>
        <p>User, Admin, and Risk review privileges are active.</p>
      </div>
      <div className="mini-card">
        <div className="mini-card-head">
          <KeyRound size={16} /> Access
        </div>
        <h3>2FA enabled</h3>
        <p>SSO + policy rotation remains compliant for sensitive teams.</p>
      </div>
      <div className="mini-card">
        <div className="mini-card-head">
          <UserCheck size={16} /> Status
        </div>
        <h3>98.4% healthy</h3>
        <p>New permission reviews and policy syncs are up to date.</p>
      </div>
    </div>
  );
}

function AgentMonitoringPanel({ provider }) {
  const metrics = [
    ["SupplierAgent", "1.3s", "Healthy"],
    ["DeliveryAgent", "1.7s", "Watching"],
    ["ForecastAgent", "2.1s", "Stable"],
    [
      "AssistantLLM",
      provider?.configured ? "Connected" : "Fallback",
      "Governed",
    ],
  ];
  return (
    <>
      <div className="kpis">
        {metrics.map(([name, latency, status]) => (
          <div className="kpi" key={name}>
            <div className="ktitle">{name}</div>
            <div className="kvalue">{latency}</div>
            <div className="kfoot">{status}</div>
          </div>
        ))}
      </div>
      <div className="panel">
        <h3>Agent execution overview</h3>
        <p>
          Runtime status, routing health, and evidence readiness across the
          specialist set.
        </p>
        <div className="status-grid">
          {metrics.map(([name, latency, status]) => (
            <div className="status-row" key={name}>
              <strong>{name}</strong>
              <span>{status}</span>
              <small>{latency}</small>
            </div>
          ))}
        </div>
      </div>
    </>
  );
}

function SystemSettingsPanel() {
  return (
    <div className="admin-grid">
      <div className="mini-card">
        <div className="mini-card-head">
          <ServerCog size={16} /> Data sync
        </div>
        <h3>Every 15 min</h3>
        <p>Warehouse, supplier, and shipment sync are scheduled and healthy.</p>
      </div>
      <div className="mini-card">
        <div className="mini-card-head">
          <ShieldCheck size={16} /> Security
        </div>
        <h3>Audit mode</h3>
        <p>All decisions retain trace metadata without persisting prompts.</p>
      </div>
      <div className="mini-card">
        <div className="mini-card-head">
          <SlidersHorizontal size={16} /> Model settings
        </div>
        <h3>Grounded fallback</h3>
        <p>LLM provider can reconnect automatically when configured.</p>
      </div>
      <div className="mini-card">
        <div className="mini-card-head">
          <RefreshCw size={16} /> Refresh cadence
        </div>
        <h3>Live refresh</h3>
        <p>Network health checks are enabled for all control-tower views.</p>
      </div>
    </div>
  );
}
function Overview({ s, stock, trends, risks, simulation }) {
  const cards = [
    [
      ShoppingBasket,
      "Order volume",
      fmt(s.unique_orders),
      "Synthetic quick-commerce orders",
    ],
    [
      AlertTriangle,
      "Late deliveries",
      fmt(s.late_orders),
      `${s.late_rate_pct}% marked late`,
    ],
    [
      Warehouse,
      "Inventory coverage",
      fmt(stock.high_risk),
      "Synthetic inventory snapshot",
    ],
    [
      Truck,
      "Avg delivery",
        formatDuration(s.avg_delivery_minutes),
        `Scheduled ${formatDuration(s.avg_promised_minutes)}`,
    ],
  ];
  return (
    <>
      <section className="hero">
        <div>
          <span className="hero-chip">
            <Sparkles size={14} /> Synthetic quick-commerce analytics
          </span>
          <h2>See delivery risk before it becomes a customer problem.</h2>
          <p>
            SupplyMuse connects synthetic delivery, demand, inventory, and
            explainable recommendations in one workspace.
          </p>
        </div>
        <div className="hero-stat">
          <span>What-if model ready</span>
          <b>{simulation?.parameters?.supplier_name || "Loading network"}</b>
          <small>Historical demand proxy vs delayed-receipt scenario</small>
        </div>
      </section>
      <div className="kpis">
        {cards.map(([I, t, v, sub]) => (
          <div className="kpi" key={t}>
            <div className="kicon">
              <I size={18} />
            </div>
            <div className="ktitle">{t}</div>
            <div className="kvalue">{v}</div>
            <div className="kfoot">{sub}</div>
          </div>
        ))}
      </div>
      <div className="grid-2">
        <Chart
          title="Network demand flow"
          sub="Daily synthetic quick-commerce orders across the demo network."
          data={trends}
          mode="orders"
        />
        <TablePanel
          title="Priority queue"
          sub="Highest-priority orders by explainable delivery risk."
        >
          <RiskTable rows={risks.slice(0, 7)} />
        </TablePanel>
      </div>
    </>
  );
}
function Simulation({ simulation, suppliers, onRun }) {
  const [p, setP] = useState({
    supplier_id: simulation?.parameters?.supplier_id || "",
    delay_days: simulation?.parameters?.delay_days || 3,
    demand_multiplier: simulation?.parameters?.demand_multiplier || 1,
    horizon: simulation?.parameters?.horizon_days || 14,
  });
  const [playing, setPlaying] = useState(false);
  const [day, setDay] = useState(1);
  useEffect(() => {
    if (!simulation) return;
    setP((x) => ({
      ...x,
      supplier_id: x.supplier_id || simulation.parameters.supplier_id,
    }));
    setDay(1);
  }, [simulation]);
  useEffect(() => {
    if (!playing || !simulation) return;
    const i = setInterval(
      () =>
        setDay((d) =>
          d >= simulation.timeline.length ? (setPlaying(false), 1) : d + 1,
        ),
      750,
    );
    return () => clearInterval(i);
  }, [playing, simulation]);
  if (!simulation)
    return <div className="loading">Preparing the digital twin...</div>;
  const impact = simulation.impact || {},
    active =
      simulation.timeline.find((x) => x.day === day) || simulation.timeline[0];
  return (
    <>
      <section className="sim-head">
        <div>
          <span className="hero-chip">
            <Route size={14} /> Read-only what-if
          </span>
          <h2>Rehearse a disruption before it happens.</h2>
          <p>
            SupplyMuse uses the same starting inventory for both paths, then
            shifts supplier receipt dates and demand pressure to show the
            operational consequence.
          </p>
        </div>
        <button
          className="primary"
          onClick={() => {
            setPlaying(true);
            onRun(p);
          }}
        >
          <Play size={16} />
          Run scenario
        </button>
      </section>
      <div className="sim-controls">
        <label>
          Supplier
          <select
            value={p.supplier_id}
            onChange={(e) => setP({ ...p, supplier_id: e.target.value })}
          >
            {suppliers.map((x) => (
              <option key={x.supplier_id} value={x.supplier_id}>
                {x.supplier_name} Â· {x.risk_level}
              </option>
            ))}
          </select>
        </label>
        <label>
          Receipt delay <b>{p.delay_days} days</b>
          <input
            type="range"
            min="0"
            max="14"
            value={p.delay_days}
            onChange={(e) => setP({ ...p, delay_days: +e.target.value })}
          />
        </label>
        <label>
          Demand pressure <b>{p.demand_multiplier}x</b>
          <input
            type="range"
            min="0.5"
            max="2"
            step="0.1"
            value={p.demand_multiplier}
            onChange={(e) => setP({ ...p, demand_multiplier: +e.target.value })}
          />
        </label>
        <label>
          Horizon
          <select
            value={p.horizon}
            onChange={(e) => setP({ ...p, horizon: +e.target.value })}
          >
            <option value="7">7 days</option>
            <option value="14">14 days</option>
            <option value="21">21 days</option>
            <option value="30">30 days</option>
          </select>
        </label>
      </div>
      <section className="sim-canvas">
        <div className="sim-toolbar">
          <div>
            <b>
              Day {day} of {simulation.timeline.length}
            </b>
            <small>
              {simulation.parameters.delay_days
                ? `Disruption: +${simulation.parameters.delay_days} day delayed receipt`
                : "No receipt delay applied"}
            </small>
          </div>
          <div>
            <button
              className="icon-button"
              onClick={() => setPlaying(!playing)}
            >
              {playing ? "Pause" : "Play"}
            </button>
            <button className="icon-button" onClick={() => setDay(1)}>
              <RotateCcw size={14} />
            </button>
          </div>
        </div>
        <div className="network-flow">
          <FlowNode
            kind="supplier"
            icon={<Factory />}
            title={simulation.network.supplier.name}
            subtitle={`${simulation.network.supplier.risk_level} risk Â· ${simulation.network.supplier.lead_time_days}d lead`}
            active={
              day <=
              simulation.parameters.delay_days +
                simulation.network.supplier.lead_time_days
            }
          />
          <div className={`flow-link ${playing ? "moving" : ""}`}>
            <Truck size={20} />
            <span>
              {simulation.parameters.delay_days
                ? `Receipt shifted +${simulation.parameters.delay_days}d`
                : "On-time replenishment"}
            </span>
          </div>
          <FlowNode
            kind="hub"
            icon={<Boxes />}
            title="Inbound control"
            subtitle={`${simulation.network.planned_replenishment_units.toLocaleString()} planned units`}
            active={active.receiving > 0}
          />
          <div className={`flow-link ${playing ? "moving" : ""}`}>
            <Route size={20} />
            <span>{active.receiving} SKU-stores receiving</span>
          </div>
          <div className="store-cluster">
            {simulation.network.stores_by_city.slice(0, 4).map((x, i) => (
              <FlowNode
                key={x.city}
                kind="store"
                icon={<Store />}
                title={x.city}
                subtitle={`${x.sku_store_records} SKU-stores`}
                active={i < Math.max(1, active.scenario_stockouts)}
              />
            ))}
          </div>
        </div>
        <div className="sim-kpis">
          <Metric
            label="Scenario service"
            value={`${active.scenario_service_pct}%`}
            danger={active.scenario_service_pct < active.baseline_service_pct}
          />
          <Metric
            label="Baseline service"
            value={`${active.baseline_service_pct}%`}
          />
          <Metric
            label="Scenario stockouts"
            value={active.scenario_stockouts}
          />
          <Metric label="On-hand units" value={fmt(active.scenario_on_hand)} />
        </div>
      </section>
      <div className="grid-2">
        <Chart
          title="Service level: baseline vs scenario"
          sub="Impact of delayed replenishment over the selected horizon."
          data={simulation.timeline}
          mode="simulation"
        />
        <TablePanel
          title="Additional impact"
          sub="SKU-store records with extra stockout days versus the baseline."
        >
          <div className="tablewrap">
            <table>
              <thead>
                <tr>
                  <th>SKU / product</th>
                  <th>Store</th>
                  <th>Added stockout days</th>
                  <th>Ending stock</th>
                </tr>
              </thead>
              <tbody>
                {simulation.affected_sku_stores.map((x, i) => (
                  <tr key={i}>
                    <td>
                      {x.sku_id}
                      <small>{x.product_name}</small>
                    </td>
                    <td>
                      {x.store_id} / {x.city}
                    </td>
                    <td>
                      <Badge
                        value={
                          x.additional_stockout_days > 2 ? "High" : "Medium"
                        }
                      />{" "}
                      {x.additional_stockout_days}
                    </td>
                    <td>{x.scenario_ending_stock}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TablePanel>
      </div>
      <TablePanel
        title="How this simulation works"
        sub="Deterministic causal chain and guardrails."
      >
        <ol className="causal">
          {simulation.explainability.causal_chain.map((x) => (
            <li key={x}>{x}</li>
          ))}
        </ol>
        <div className="notice small">
          <b>Assumptions:</b> {simulation.assumptions.join(" ")}
        </div>
      </TablePanel>
    </>
  );
}
function FlowNode({ icon, title, subtitle, kind, active }) {
  return (
    <div className={`flow-node ${kind} ${active ? "active" : ""}`}>
      <div>{icon}</div>
      <b>{title}</b>
      <small>{subtitle}</small>
    </div>
  );
}
function Metric({ label, value, danger }) {
  return (
    <div className={`sim-metric ${danger ? "danger" : ""}`}>
      <small>{label}</small>
      <b>{value}</b>
    </div>
  );
}
function AgentStudio({ latest, provider }) {
  const [run, setRun] = useState(false);
  const [step, setStep] = useState(0);
  const agents = [
    ["SupplierRiskAgent", "Supplier reliability and inbound variance"],
    ["DeliveryRiskAgent", "Lead-time anomalies and late receipts"],
    ["InventoryRiskAgent", "Cover, reorder points, and stockout exposure"],
    ["DemandForecastAgent", "Trained demand outlook and validation"],
    ["SupplyChainInsightAgent", "Cross-risk evidence synthesis"],
    ["RiskRecommendationAgent", "Reviewable mitigation options"],
  ];
  useEffect(() => {
    if (!run) return;
    const i = setInterval(
      () =>
        setStep((x) =>
          x >= agents.length ? (setRun(false), agents.length) : x + 1,
        ),
      700,
    );
    return () => clearInterval(i);
  }, [run]);
  return (
    <>
      <section className="sim-head">
        <div>
          <span className="hero-chip">
            <Radio size={14} /> On-demand agent visualizer
          </span>
          <h2>Watch the decision team assemble.</h2>
          <p>
            This is a live representation of the orchestration pattern. It shows
            specialist activation, evidence handoffs, synthesis, and
            recommendation delivery.
          </p>
        </div>
        <button
          className="primary"
          onClick={() => {
            setStep(0);
            setRun(true);
          }}
        >
          <Play size={16} />
          Run agent flow
        </button>
      </section>
      <section className="agent-canvas">
        <div className="agent-orbit">
          <div className="orchestrator">
            <Sparkles />
            <b>SupplyMuse</b>
            <small>Orchestrator</small>
          </div>
          {agents.map(([name, desc], i) => (
            <div
              className={`agent-card a${i} ${step > i ? "working" : ""} ${step > i + 1 ? "done" : ""}`}
              key={name}
            >
              <Bot size={18} />
              <div>
                <b>{name.replace("Agent", "")}</b>
                <small>{desc}</small>
              </div>
              <span>
                {step > i + 1 ? "Done" : step > i ? "Working" : "Queued"}
              </span>
            </div>
          ))}
        </div>
        <div className="agent-log">
          <h3>Execution stream</h3>
          {agents.slice(0, step).map(([n, d], i) => (
            <div key={n}>
              <span>{String(i + 1).padStart(2, "0")}</span>
              <b>{n}</b>
              <small>{d}</small>
            </div>
          ))}
          {!step && <p>Start the flow to see the agent handoff sequence.</p>}
          <div className="provider-state">
            <Radio size={14} />
            {provider?.configured
              ? `${provider.provider} renders the grounded final response`
              : "Local deterministic fallback active"}
          </div>
        </div>
      </section>
      {latest?.audit && (
        <TablePanel
          title="Most recent live decision"
          sub="The assistant response generated this auditable workflow."
        >
          <div className="trace-summary">
            <b>Trace {latest.audit.trace_id}</b>
            <span>{latest.audit.duration_ms} ms</span>
            <span>{latest.audit.dataset_version}</span>
          </div>
          <pre>{JSON.stringify(latest.trace, null, 2)}</pre>
        </TablePanel>
      )}
    </>
  );
}
function Chart({ title, sub, data, mode }) {
  return (
    <section className="panel">
      <h3>{title}</h3>
      <p>{sub}</p>
      <div className="chart">
        <ResponsiveContainer width="100%" height="100%">
          {mode === "simulation" ? (
            <AreaChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" />
              <YAxis domain={[0, 100]} />
              <Tooltip />
              <Area
                dataKey="baseline_service_pct"
                name="Baseline"
                stroke="#38a384"
                fill="#38a384"
                fillOpacity={0.1}
              />
              <Area
                dataKey="scenario_service_pct"
                name="Scenario"
                stroke="#e06c57"
                fill="#e06c57"
                fillOpacity={0.12}
              />
            </AreaChart>
          ) : (
            <AreaChart data={data}>
              <CartesianGrid strokeDasharray="3 3" />
              <XAxis dataKey="day" tick={{ fontSize: 10 }} interval={12} />
              <YAxis />
              <Tooltip />
              <Area
                dataKey="orders"
                name="Orders"
                stroke="#6c63ff"
                fill="#6c63ff"
                fillOpacity={0.13}
              />
            </AreaChart>
          )}
        </ResponsiveContainer>
      </div>
    </section>
  );
}
function TablePanel({ title, sub, children }) {
  return (
    <section className="panel">
      <h3>{title}</h3>
      <p>{sub}</p>
      {children}
    </section>
  );
}
function RiskTable({ rows = [] }) {
  return (
    <div className="tablewrap">
      <table>
        <thead>
          <tr>
            <th>Order</th>
            <th>Product</th>
            <th>Supplier</th>
            <th>Delay</th>
            <th>Risk</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((x, i) => (
            <tr key={i}>
              <td className="mono">{x.order_id}</td>
              <td>
                {x.product_name}
                <small>
                  {x.city} / {x.category}
                </small>
              </td>
              <td>{x.supplier_id}</td>
              <td>{formatDuration(x.delivery_delay_minutes)} late</td>
              <td>
                <Badge value={`${x.risk_level} ${x.risk_score}`} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
function Inventory({ rows, stock }) {
  return (
    <>
      <div className="kpis">
        {[
          ["High demand exposure", stock.high_risk],
          ["Low proxy cover (<1d)", stock.low_cover_records],
          ["Demand-proxy records", stock.sku_store_records],
          ["Medium demand exposure", stock.medium_risk],
        ].map(([t, v]) => (
          <div className="kpi" key={t}>
            <div className="ktitle">{t}</div>
            <div className="kvalue">{fmt(v)}</div>
            <div className="kfoot">Synthetic inventory snapshot</div>
          </div>
        ))}
      </div>
      <div className="notice">
        <b>Synthetic demo inventory:</b> This view uses generated on-hand
        inventory, demand, and replenishment values for quick-commerce
        scenario testing.
      </div>
      <TablePanel
        title="Inventory availability"
        sub="Synthetic on-hand inventory compared with replenishment lead time."
      >
        <div className="tablewrap">
          <table>
            <thead>
              <tr>
                <th>SKU</th>
                <th>Store</th>
                <th>On hand</th>
                <th>Days of cover</th>
                <th>Lead time</th>
                <th>Stockout risk</th>
              </tr>
            </thead>
            <tbody>
              {rows.map((x, i) => (
                <tr key={i}>
                  <td>
                    {x.sku_id}
                    <small>{x.product_name}</small>
                  </td>
                  <td>
                    {x.store_id} / {x.city}
                  </td>
                  <td>{x.on_hand_units}</td>
                  <td>{x.days_of_cover}</td>
                  <td>{x.lead_time_days}d</td>
                  <td>
                    <Badge value={x.stockout_risk || "Low"} />
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </TablePanel>
    </>
  );
}
function Forecast({ forecast }) {
  return (
    <>
      <div className="notice">
        <b>{forecast.model}:</b> trained on trend and seasonality; evaluated
        with a chronological holdout.
      </div>
      <div className="kpis">
        {[
          ["MAE", forecast.metrics?.mae],
          ["RMSE", forecast.metrics?.rmse],
          ["MAPE", `${forecast.metrics?.mape || 0}%`],
        ].map(([t, v]) => (
          <div className="kpi" key={t}>
            <div className="ktitle">{t}</div>
            <div className="kvalue">{v || "-"}</div>
            <div className="kfoot">Validation performance</div>
          </div>
        ))}
      </div>
      <Chart
        title="Demand forecast"
        sub={`Features: ${(forecast.explainability?.features || []).join(", ")}`}
        data={
          forecast.series?.map((x) => ({
            ...x,
            day: x.date,
            orders: x.actual_units || x.forecast_units,
          })) || []
        }
        mode="orders"
      />
    </>
  );
}
function AnomalyTable({ rows = [] }) {
  return (
    <div className="tablewrap">
      <table>
        <thead>
          <tr>
            <th>Alert</th>
            <th>Entity</th>
            <th>Affected</th>
            <th>Score</th>
            <th>Evidence</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((x, i) => (
            <tr key={i}>
              <td>{x.type}</td>
              <td>{x.entity}</td>
              <td>{x.affected}</td>
              <td>{x.score}</td>
              <td>{x.evidence}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
function SupplierTable({ rows = [] }) {
  return (
    <div className="tablewrap">
      <table>
        <thead>
          <tr>
            <th>Supplier</th>
            <th>Late rate</th>
            <th>Inbound variability</th>
            <th>Score</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {rows.map((x, i) => (
            <tr key={i}>
              <td>
                {x.supplier_name}
                <small>{x.supplier_id}</small>
              </td>
              <td>{x.late_rate_pct}%</td>
              <td>
                {Number(x.inbound_lead_time_std_days || 0).toFixed(2)} days
              </td>
              <td>{x.risk_score}</td>
              <td>
                <Badge value={x.risk_level} />
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
function RiskReport({ report }) {
  return (
    <>
      <TablePanel title="Executive risk brief" sub={report.headline}>
        <div className="notice small">
          <b>Scoring:</b> {report.risk_model?.name}. High risk{" "}
          {report.risk_model?.levels?.High}.
        </div>
        <ul className="actions">
          {(report.recommended_actions || []).map((x) => (
            <li key={x}>{x}</li>
          ))}
        </ul>
      </TablePanel>
      <TablePanel
        title="Suppliers requiring review"
        sub="Highest weighted risk."
      >
        <SupplierTable rows={report.top_suppliers || []} />
      </TablePanel>
    </>
  );
}
function Assistant({ chat, q, setQ, ask, asking, provider }) {
  const prompts = [
    "Which SKUs are at highest stockout risk?",
    "Which suppliers have the highest late rate?",
    "Show demand forecast accuracy",
    "What anomalies need investigation?",
  ];
  const assistantMessages = chat.filter((m) => m.role === "assistant");
  const [selectedMessageId, setSelectedMessageId] = useState(null);
  useEffect(() => {
    if (!assistantMessages.length) {
      setSelectedMessageId(null);
      return;
    }
    if (
      !selectedMessageId ||
      !assistantMessages.some((m) => m.id === selectedMessageId)
    ) {
      setSelectedMessageId(assistantMessages[assistantMessages.length - 1].id);
    }
  }, [assistantMessages, selectedMessageId]);
  const selectedMessage =
    assistantMessages.find((m) => m.id === selectedMessageId) ||
    assistantMessages[assistantMessages.length - 1];
  return (
    <div className="assistant">
      <section className="panel chatpanel">
        <div className="chathead">
          <div className="muse-mark small">
            <Sparkles size={17} />
            <i />
          </div>
          <div>
            <h3>SupplyMuse analyst</h3>
            <p>
              Grounded decisions with evidence, agent handoffs, and trace IDs.
            </p>
          </div>
          <span className={`llmstate ${provider?.configured ? "on" : ""}`}>
            {provider?.configured
              ? `${provider.provider} connected`
              : "Local fallback ready"}
          </span>
        </div>
        <div className="prompts">
          {prompts.map((x) => (
            <button key={x} disabled={asking} onClick={() => ask(x)}>
              {x}
            </button>
          ))}
        </div>
        <div className="messages">
          {!chat.length && (
            <div className="welcome">
              <h2>Ask the supply network</h2>
              <p>
                SupplyMuse routes your question to the relevant specialist
                agents and returns evidence you can inspect.
              </p>
            </div>
          )}
          {chat.map((m, i) => (
            <div className={`message ${m.role}`} key={m.id || i}>
              <div className="bubble">
                <div className="message-header">
                  <span>{m.role === "assistant" ? "SupplyMuse" : "You"}</span>
                  {m.role === "assistant" && (
                    <button
                      type="button"
                      className={`tiny-btn ${selectedMessage?.id === m.id ? "active" : ""}`}
                      onClick={() => setSelectedMessageId(m.id)}
                    >
                      {selectedMessage?.id === m.id ? "Selected" : "Inspect"}
                    </button>
                  )}
                </div>
                <MessageText text={m.text} />
                {m.note && <small className="note">{m.note}</small>}
                {m.audit && (
                  <small className="traceid">
                    Trace {m.audit.trace_id || "pending"} ·{" "}
                    {m.audit.duration_ms || 0} ms · dataset{" "}
                    {m.audit.dataset_version || "unknown"}
                  </small>
                )}
              </div>
            </div>
          ))}
          {asking && (
            <div className="message assistant">
              <div className="bubble">
                <div className="message-header">
                  <span>SupplyMuse</span>
                </div>
                <div className="message-body">
                  Gathering the latest evidence for your question…
                </div>
              </div>
            </div>
          )}
        </div>
        <form
          className="askbar"
          onSubmit={(e) => {
            e.preventDefault();
            ask();
          }}
        >
          <input
            disabled={asking}
            value={q}
            onChange={(e) => setQ(e.target.value)}
            placeholder="Ask about suppliers, delays, inventory, or demand..."
          />
          <button disabled={asking} aria-label="Send question">
            <Send size={17} />
          </button>
        </form>
      </section>
      <aside className="panel assistant-detail">
        {selectedMessage ? (
          <>
            {" "}
            <div className="detail-header">
              <span className="eyebrow eyebrow-brown">Message analysis</span>
              <h3>Trace and retrieval</h3>
            </div>
            <div className="analysis-scroll">
            <div className="trace-summary-box">
              <div className="summary-row">
                <span>Trace</span>
                <strong>
                  {selectedMessage.audit?.trace_id || "Not available"}
                </strong>
              </div>
              <div className="summary-row">
                <span>Duration</span>
                <strong>{selectedMessage.audit?.duration_ms || 0} ms</strong>
              </div>
              <div className="summary-row">
                <span>Dataset</span>
                <strong>
                  {selectedMessage.audit?.dataset_version || "Synthetic demo"}
                </strong>
              </div>
              <div className="summary-row">
                <span>Agents</span>
                <strong>
                  {(
                    selectedMessage.routed_agents ||
                    selectedMessage.trace?.map((x) => x.agent || x.name) ||
                    []
                  ).join(", ") || "No route recorded"}
                </strong>
              </div>
            </div>
            <div className="evidence-section">
              <h4>Retrieval response</h4>
              {selectedMessage.evidence?.length ? (
                selectedMessage.evidence.map((item, idx) => (
                  <div
                    className="evidence-card"
                    key={`${selectedMessage.id || idx}-${idx}`}
                  >
                    <div className="evidence-card-head">
                      <strong>
                        {item.agent || item.name || `Evidence ${idx + 1}`}
                      </strong>
                      <span>{item.stage || "agent"}</span>
                    </div>
                    <p>
                      {formatStructuredValue(
                        item.explanation ||
                          item.summary ||
                          item.transformation ||
                          "No explanation available.",
                      )}
                    </p>
                    {item.source && (
                      <div className="evidence-meta">
                        <span>Source</span>
                        <b>{formatStructuredValue(item.source)}</b>
                      </div>
                    )}
                    {item.transformation && (
                      <div className="evidence-meta">
                        <span>Transformation</span>
                        <b>{formatStructuredValue(item.transformation)}</b>
                      </div>
                    )}
                    {item.records &&
                      Array.isArray(item.records) &&
                      item.records.length > 0 && (
                        <div className="evidence-records">
                          <h5>Sample records</h5>
                          <pre>
                            {JSON.stringify(item.records.slice(0, 4), null, 2)}
                          </pre>
                        </div>
                      )}
                  </div>
                ))
              ) : (
                <div className="empty-state-small">
                  No retrieval evidence is attached to this response.
                </div>
              )}
            </div>
            {selectedMessage.trace?.length > 0 && (
              <div className="trace-section">
                <h4>Agent trace</h4>
                {selectedMessage.trace.map((node, index) => (
                  <div
                    className="trace-step"
                    key={`${selectedMessage.id}-trace-${index}`}
                  >
                    <span>{index + 1}</span>
                    <div>
                      <strong>{node.agent || node.name || "Trace step"}</strong>
                      <small>
                        {node.stage || node.action || "Operational step"}
                      </small>
                    </div>
                  </div>
                ))}
              </div>
            )}{" "}
            </div>
          </>
        ) : (
          <div className="empty-state">
            <h3>No message selected</h3>
            <p>
              Select one of the assistant replies to inspect the trace and
              retrieval output.
            </p>
          </div>
        )}
      </aside>
    </div>
  );
}
function EvaluationPanel({ report = {} }) {
  const routeResults = report.assistant_routing || [];
  const totalRoutes = routeResults.length;
  const passedRoutes = routeResults.filter((x) => x.passed).length;
  const avgEvidence = routeResults.length
    ? Math.round(
        routeResults.reduce(
          (sum, x) => sum + (Number(x.evidence_items) || 0),
          0,
        ) / routeResults.length,
      )
    : 0;
  const auditQuality = report.auditability || {};
  const forecast = report.forecast_accuracy || {};
  return (
    <div className="evaluation-panel">
      <div className="kpis">
        {[
          [
            "Trace audit",
            auditQuality.all_agent_routes_have_audit_events ? "Pass" : "Review",
          ],
          ["Retrieval quality", `${avgEvidence} evidence items avg`],
          ["Forecast MAPE", forecast.mape === undefined ? "n/a" : `${forecast.mape}%`],
        ].map(([t, v]) => (
          <div className="kpi" key={t}>
            <div className="ktitle">{t}</div>
            <div className="kvalue">{v}</div>
            <div className="kfoot">Project evaluation</div>
          </div>
        ))}
      </div>
      <div className="evaluation-grid">
        <TablePanel
          title="Trace evaluation"
          sub="Decision traces and auditability checks."
        >
          <div className="metric-list">
            <div className="metric-row">
              <span>Routes checked</span>
              <b>{totalRoutes}</b>
            </div>
            <div className="metric-row">
              <span>Passed routes</span>
              <b>{passedRoutes}</b>
            </div>
            <div className="metric-row">
              <span>Audit events complete</span>
              <b>
                {auditQuality.all_agent_routes_have_audit_events ? "Yes" : "No"}
              </b>
            </div>
          </div>
          <div className="evaluation-note">
            <ShieldCheck size={16} />
            <span>
              {auditQuality.privacy_policy ||
                "All evaluated routes include auditable decision events."}
            </span>
          </div>
        </TablePanel>
        <TablePanel
          title="Assistant retrieval results"
          sub="Evidence returned for each routed query."
        >
          <div className="tablewrap">
            <table>
              <thead>
                <tr>
                  <th>Question</th>
                  <th>Route</th>
                  <th>Evidence</th>
                  <th>Status</th>
                </tr>
              </thead>
              <tbody>
                {routeResults.map((item, i) => (
                  <tr key={i}>
                    <td>{item.question}</td>
                    <td>{item.routed_agents?.join(", ") || "—"}</td>
                    <td>{item.evidence_items}</td>
                    <td>
                      <Badge value={item.passed ? "Passed" : "Failed"} />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </TablePanel>
        <TablePanel
          title="Forecast and project metrics"
          sub="Quantitative evaluation of model and scenario health."
        >
          <div className="metric-list">
            <div className="metric-row">
              <span>MAE</span>
              <b>{forecast.mae ?? "—"}</b>
            </div>
            <div className="metric-row">
              <span>RMSE</span>
              <b>{forecast.rmse ?? "—"}</b>
            </div>
            <div className="metric-row">
              <span>MAPE</span>
              <b>{forecast.mape ?? "—"}</b>
            </div>
            <div className="metric-row">
              <span>Service delta</span>
              <b>{report.simulation?.service_delta_points ?? "—"}</b>
            </div>
          </div>
          <ul className="actions">
            {(report.limitations || []).map((x) => (
              <li key={x}>{x}</li>
            ))}
          </ul>
        </TablePanel>
      </div>
    </div>
  );
}
function Audit({ metrics, traces, explain }) {
  const [detail, setDetail] = useState(null);
  const inspect = async (id) => setDetail(await get(`audit/traces/${id}`));
  return (
    <>
      <div className="notice">
        <b>Audit policy:</b> {metrics.privacy}
      </div>
      <div className="kpis">
        {[
          ["Decision traces", metrics.total_traces],
          ["Success rate", `${metrics.success_rate_pct || 0}%`],
          ["Avg duration", `${metrics.average_trace_duration_ms || 0} ms`],
        ].map(([t, v]) => (
          <div className="kpi" key={t}>
            <div className="ktitle">{t}</div>
            <div className="kvalue">{v}</div>
            <div className="kfoot">SQLite WAL audit ledger</div>
          </div>
        ))}
      </div>
      <TablePanel
        title="Stage observability"
        sub="Execution count, average duration, and error capture per stage."
      >
        <div className="tablewrap">
          <table>
            <thead>
              <tr>
                <th>Stage</th>
                <th>Component</th>
                <th>Runs</th>
                <th>Avg time</th>
                <th>Errors</th>
              </tr>
            </thead>
            <tbody>
              {(metrics.stage_metrics || []).map((x, i) => (
                <tr key={i}>
                  <td>{x.stage}</td>
                  <td>{x.component}</td>
                  <td>{x.count}</td>
                  <td>{x.avg_duration_ms} ms</td>
                  <td>{x.errors}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </TablePanel>
      <TablePanel
        title="Decision traces"
        sub="Inspect method, source, outcome and timing. No raw questions or prompts are stored."
      >
        <div className="tablewrap">
          <table>
            <thead>
              <tr>
                <th>Trace</th>
                <th>Status</th>
                <th>Duration</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {traces.map((x) => (
                <tr key={x.trace_id}>
                  <td className="mono">{x.trace_id}</td>
                  <td>
                    <Badge value={x.status} />
                  </td>
                  <td>{x.duration_ms} ms</td>
                  <td>
                    <button
                      className="inspect"
                      onClick={() => inspect(x.trace_id)}
                    >
                      Inspect
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
        {detail && (
          <pre className="trace-detail">
            {JSON.stringify(detail.events, null, 2)}
          </pre>
        )}
      </TablePanel>
      <TablePanel
        title="Model and data provenance"
        sub={`Dataset version ${explain.data_lineage?.dataset_version || "-"}`}
      >
        <div className="provenance">
          <pre>{JSON.stringify(explain.risk_taxonomy || {}, null, 2)}</pre>
          <pre>
            {JSON.stringify(explain.forecast?.coefficients || {}, null, 2)}
          </pre>
        </div>
      </TablePanel>
    </>
  );
}
function Quality({ quality }) {
  return (
    <TablePanel
      title="Data quality and lineage"
      sub="Schema checks and deterministic data preparation."
    >
      <div className="kpis compact">
        {[
          ["Order rows", quality.rows],
          ["Columns", quality.columns],
          ["Missing cells", quality.missing_cells],
          ["Duplicates", quality.duplicate_rows],
        ].map(([t, v]) => (
          <div className="kpi" key={t}>
            <div className="ktitle">{t}</div>
            <div className="kvalue">{fmt(v)}</div>
          </div>
        ))}
      </div>
      <ul className="actions">
        {(quality.preprocessing || []).map((x) => (
          <li key={x}>{x}</li>
        ))}
      </ul>
      <pre>{JSON.stringify(quality.lineage || {}, null, 2)}</pre>
    </TablePanel>
  );
}

const rootElement = document.getElementById("root");
if (!rootElement) {
  throw new Error("SupplyMuse root element not found");
}
if (!rootElement.__supplyMuseRoot) {
  rootElement.__supplyMuseRoot = createRoot(rootElement);
}
rootElement.__supplyMuseRoot.render(
  <AppErrorBoundary>
    <App />
  </AppErrorBoundary>,
);
