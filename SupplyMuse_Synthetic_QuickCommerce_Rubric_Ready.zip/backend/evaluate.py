"""Repeatable evaluation checks for the SupplyMuse capstone.

Run from backend: python evaluate.py
Writes data/evaluation_report.json for submission evidence.
"""
import json
from pathlib import Path
from app.analytics import anomalies, forecast, risk_report, supplier_scorecards, supply_chain_simulation
from app.agents import orchestrator
from app.audit import AuditTrace, trace_detail
from app.data import quality_report

CASES = [
    ("Which suppliers have delivery risk?", "SupplierRiskAgent"),
    ("Show delivery delays and lead time outliers", "DeliveryRiskAgent"),
    ("Which inventory SKUs may stock out?", "InventoryRiskAgent"),
    ("What is the demand forecast accuracy?", "DemandForecastAgent"),
]
def main():
    q = quality_report(); fc = forecast(); agent_results = []
    baseline_simulation = supply_chain_simulation(horizon=14)
    disruption_simulation = supply_chain_simulation(baseline_simulation["parameters"]["supplier_id"], delay_days=7, demand_multiplier=1.3, horizon=14)
    for question, expected in CASES:
        trace = AuditTrace("evaluation", question, {"case": expected})
        response = orchestrator.run(question, trace); final = trace.complete(); agents = response["routed_agents"]
        audit = trace_detail(final["trace_id"]); event_stages = [event["stage"] for event in audit["events"]]
        agent_results.append({"question": question, "expected_agent": expected, "routed_agents": agents, "passed": expected in agents, "evidence_items": len(response["evidence"]), "audit_events": len(event_stages), "audit_passed": event_stages[0] == "routing" and event_stages.count("agent") == len(agents)})
    result = {
        "data_quality": {"schema_valid": q["schema_valid"], "missing_cells": q["missing_cells"], "duplicate_rows": q["duplicate_rows"]},
        "forecast_accuracy": fc["metrics"],
        "supplier_risk": {"scorecards": len(supplier_scorecards()), "high_risk_suppliers": int((supplier_scorecards().risk_level == "High").sum())},
        "anomaly_detection": {"alerts": len(anomalies(500)), "types": sorted(set(x["type"] for x in anomalies(500)))},
        "assistant_routing": agent_results,
        "auditability": {"all_agent_routes_have_audit_events": all(x["audit_passed"] for x in agent_results), "privacy_policy": "Audit traces retain only question hashes and lengths; raw questions, prompts, full evidence rows and secrets are not persisted."},
        "simulation": {"supplier": baseline_simulation["parameters"]["supplier_id"], "baseline_service_pct": baseline_simulation["impact"]["baseline_average_service_pct"], "disrupted_service_pct": disruption_simulation["impact"]["scenario_average_service_pct"], "service_delta_points": disruption_simulation["impact"]["service_level_delta_points"], "affected_sku_stores": len(disruption_simulation["affected_sku_stores"])},
        "risk_report": {"top_suppliers": len(risk_report()["top_suppliers"]), "recommended_actions": len(risk_report()["recommended_actions"])},
        "limitations": ["This evaluates synthetic quick-commerce delivery, supplier, and inventory records generated for demonstrations.", "Forecast metrics use a chronological holdout and should be re-run after data regeneration.", "Agent routing tests verify specialist selection and evidence provenance, not subjective language quality."],
    }
    target = Path(__file__).parent / "data" / "evaluation_report.json"
    target.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2)); print(f"\nWrote {target}")
if __name__ == "__main__": main()
