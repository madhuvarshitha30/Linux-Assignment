"""Generate deterministic synthetic quick-commerce data for local SupplyMuse demos."""
from pathlib import Path
import numpy as np
import pandas as pd

BASE = Path(__file__).resolve().parent / "data"
RNG = np.random.default_rng(20260930)
CITIES = {"Bengaluru": ["Indiranagar", "Koramangala", "Whitefield"], "Mumbai": ["Andheri", "Bandra", "Powai"], "Delhi": ["Saket", "Rohini", "Dwarka"], "Hyderabad": ["Banjara Hills", "Gachibowli"], "Pune": ["Kothrud", "Viman Nagar"], "Chennai": ["Adyar", "Velachery"]}
SUPPLIERS = [("SUP-01", "FreshField Produce", "Bengaluru", .94, 1.2), ("SUP-02", "Daily Dairy Co.", "Pune", .92, 1.8), ("SUP-03", "Pantry Partners", "Mumbai", .90, 2.2), ("SUP-04", "HomeCare Hub", "Delhi", .72, 5.4), ("SUP-05", "SnackStreet Foods", "Hyderabad", .91, 1.6), ("SUP-06", "Glow & Go", "Chennai", .78, 4.8), ("SUP-07", "QuickPet Essentials", "Mumbai", .93, 1.4), ("SUP-08", "BrewBox Beverages", "Bengaluru", .87, 3.0)]
ITEMS = [("Bananas, 6 pack", "Fresh Produce", 55), ("Tomatoes, 500 g", "Fresh Produce", 42), ("Avocado, 2 pack", "Fresh Produce", 89), ("Spinach, 250 g", "Fresh Produce", 38), ("Whole Milk, 1 L", "Dairy & Eggs", 68), ("Greek Yogurt, 400 g", "Dairy & Eggs", 110), ("Eggs, 12 pack", "Dairy & Eggs", 95), ("Sourdough Bread", "Bakery", 75), ("Basmati Rice, 1 kg", "Pantry", 125), ("Pasta, 500 g", "Pantry", 72), ("Instant Noodles, 4 pack", "Pantry", 64), ("Potato Chips, 150 g", "Snacks", 55), ("Trail Mix, 200 g", "Snacks", 145), ("Cold Coffee, 250 ml", "Beverages", 75), ("Orange Juice, 1 L", "Beverages", 115), ("Laundry Liquid, 1 L", "Home Care", 235), ("Dishwash Gel, 500 ml", "Home Care", 105), ("Shampoo, 340 ml", "Personal Care", 220), ("Face Wash, 100 ml", "Personal Care", 165), ("Dog Food, 1 kg", "Pet Care", 350), ("Baby Wipes, 72 count", "Baby Care", 165), ("AA Batteries, 4 pack", "Essentials", 120), ("Ice Cream, 500 ml", "Frozen", 210), ("Frozen Peas, 500 g", "Frozen", 115), ("Ready Meal, 350 g", "Ready to Eat", 175), ("Veg Sandwich", "Ready to Eat", 135), ("Pain Relief Spray, 50 ml", "Health", 180), ("Vitamin C Tablets", "Health", 250), ("Cleaning Sponge, 3 pack", "Home Care", 48), ("Hand Sanitizer, 250 ml", "Personal Care", 75)]

def generate():
    BASE.mkdir(parents=True, exist_ok=True)
    stores = pd.DataFrame([{"store_id": f"DS-{city[:3].upper()}-{i:02d}", "store_name": f"{area} Dark Store", "city": city, "area": area, "capacity_units": int(RNG.integers(2200, 4200))} for city, areas in CITIES.items() for i, area in enumerate(areas, 1)])
    suppliers = pd.DataFrame([{"supplier_id": code, "supplier_name": name, "supplier_region": region, "avg_lead_time_days": round(float(RNG.uniform(.5, 1.5)), 2), "on_time_rate_pct": on_time * 100, "quality_issue_rate_pct": issue, "risk_tier": "Watch" if on_time < .9 else "Standard"} for code, name, region, on_time, issue in SUPPLIERS])
    products = pd.DataFrame([{"sku_id": f"SKU-{i:03d}", "product_name": name, "category": category, "supplier_id": SUPPLIERS[(i - 1) % len(SUPPLIERS)][0], "unit_price_inr": price, "reorder_point": int(RNG.integers(12, 35)), "brand": ["QuickBasket", "DailyDrop", "SwiftMart"][i % 3], "unit_cost_inr": round(price * float(RNG.uniform(.52, .72)), 2), "shelf_life_days": int(RNG.integers(3, 45)), "units_per_pack": 1} for i, (name, category, price) in enumerate(ITEMS, 1)])
    n = 12000
    store_pick = stores.iloc[RNG.integers(0, len(stores), n)].reset_index(drop=True)
    product_pick = products.iloc[RNG.integers(0, len(products), n)].reset_index(drop=True)
    time = pd.Timestamp("2026-04-01") + pd.to_timedelta(RNG.integers(0, 120 * 24 * 60, n), unit="m")
    promised = RNG.choice([10, 15, 20, 25], n, p=[.18, .44, .28, .1])
    on_time = product_pick.supplier_id.map(suppliers.set_index("supplier_id").on_time_rate_pct).to_numpy() / 100
    late = RNG.random(n) > on_time
    supplier_delay_factor = product_pick.supplier_id.map(suppliers.set_index("supplier_id")["on_time_rate_pct"]).to_numpy() / 100
    disruption = np.where(supplier_delay_factor < 0.85, RNG.gamma(2.4, 8.0, n) + 5, 0)
    actual = np.maximum(6, np.round(np.where(late, promised + RNG.gamma(2, 7, n) + 4 + disruption, promised + RNG.normal(0, 3.5, n)))).astype(int)
    quantity = RNG.choice([1, 2, 3], n, p=[.75, .2, .05])
    discount = RNG.choice([0, 5, 10, 15], n, p=[.62, .2, .13, .05])
    orders = pd.DataFrame({"order_id": [f"QC-{100000+i}" for i in range(n)], "order_item_id": [f"ITEM-{100000+i}" for i in range(n)], "order_datetime": time.strftime("%Y-%m-%d %H:%M:%S"), "city": store_pick.city, "area": store_pick.area, "store_id": store_pick.store_id, "sku_id": product_pick.sku_id, "product_name": product_pick.product_name, "category": product_pick.category, "supplier_id": product_pick.supplier_id, "quantity": quantity, "unit_price_inr": product_pick.unit_price_inr.to_numpy(), "discount_pct": discount, "order_value_inr": np.round(product_pick.unit_price_inr.to_numpy() * quantity * (1-discount/100), 2), "payment_method": RNG.choice(["UPI", "Card", "Wallet", "Cash"], n, p=[.52, .23, .16, .09]), "order_status": "Delivered", "promised_delivery_minutes": promised, "actual_delivery_minutes": actual, "delivery_delay_minutes": np.maximum(actual-promised, 0), "is_late": late.astype(int), "is_stockout_substitute": ((RNG.random(n) < .018) & (quantity > 1)).astype(int), "customer_rating": np.round(np.clip(4.7-late*RNG.uniform(.5,1.7,n)+RNG.normal(0,.22,n),1,5),1), "weather_condition": RNG.choice(["Clear", "Cloudy", "Rain"], n, p=[.62,.23,.15]), "is_peak_hour": ((time.hour >= 18) & (time.hour <= 22)).astype(int)})
    dates = pd.to_datetime(orders.order_datetime)
    recent = orders.loc[dates >= dates.max().normalize() - pd.Timedelta(days=27)]
    keys = ["store_id", "city", "sku_id", "product_name", "category", "supplier_id"]
    inventory = recent.groupby(keys, as_index=False).agg(observed_28d_units=("quantity", "sum"), avg_daily_demand_units=("quantity", lambda x: x.sum()/28))
    inventory = inventory.merge(products[["sku_id", "unit_cost_inr"]], on="sku_id").merge(suppliers[["supplier_id", "avg_lead_time_days"]], on="supplier_id").rename(columns={"avg_lead_time_days":"lead_time_days"})
    inventory["observed_7d_units"] = np.maximum(0, np.round(inventory.avg_daily_demand_units*7+RNG.normal(0,2,len(inventory)))).astype(int)
    inventory["reorder_point_units"] = np.ceil(inventory.avg_daily_demand_units*inventory.lead_time_days*1.7).clip(lower=2)
    inventory["on_hand_units"] = np.maximum(0, np.round(inventory.reorder_point_units*RNG.uniform(.45,2.4,len(inventory)))).astype(int)
    inventory["days_of_cover"] = (inventory.on_hand_units/inventory.avg_daily_demand_units.replace(0,np.nan)).fillna(0).round(2)
    inventory["snapshot_date"] = dates.max().normalize().date()
    inventory["stockout_risk"] = pd.cut(inventory.days_of_cover/inventory.lead_time_days, [-np.inf,.8,1.4,np.inf], labels=["High","Medium","Low"]).astype(str)
    shipments = orders[["order_item_id","supplier_id","sku_id","store_id","city","promised_delivery_minutes","actual_delivery_minutes","is_late","quantity"]].copy()
    shipments["shipment_id"] = "SHIP-"+shipments.order_item_id
    shipments["shipment_created_date"] = dates.dt.date
    shipments["planned_receipt_date"] = (dates+pd.to_timedelta(shipments.promised_delivery_minutes,unit="m")).dt.date
    shipments["actual_receipt_date"] = (dates+pd.to_timedelta(shipments.actual_delivery_minutes,unit="m")).dt.date
    shipments["planned_lead_time_days"] = (shipments.promised_delivery_minutes/1440).round(3)
    shipments["actual_lead_time_days"] = (shipments.actual_delivery_minutes/1440).round(3)
    shipments["lead_time_variance_days"] = ((shipments.actual_delivery_minutes-shipments.promised_delivery_minutes)/1440).round(3)
    shipments["is_late_receipt"] = shipments.is_late
    shipments["shipment_units"] = shipments.quantity
    shipments = shipments[["shipment_id","supplier_id","sku_id","store_id","city","shipment_created_date","planned_receipt_date","actual_receipt_date","planned_lead_time_days","actual_lead_time_days","lead_time_variance_days","is_late_receipt","shipment_units"]]
    daily = orders.assign(date=dates.dt.date).groupby(["date","city","category"],as_index=False).agg(units_sold=("quantity","sum"),order_lines=("order_id","count"),revenue_inr=("order_value_inr","sum"))
    for name, frame in {"orders":orders,"products":products,"suppliers":suppliers,"dark_stores":stores,"inventory":inventory,"inbound_shipments":shipments,"daily_demand":daily}.items(): frame.to_csv(BASE/f"{name}.csv",index=False)
    print(f"Generated {len(orders):,} synthetic quick-commerce orders.")

if __name__ == "__main__":
    generate()
