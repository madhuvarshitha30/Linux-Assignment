import json, os, httpx
from .agents import orchestrator
from .audit import AuditTrace

PROVIDERS={
 'openrouter':{'base':'https://openrouter.ai/api/v1','model':'openrouter/free','key':'OPENROUTER_API_KEY'},
 'openai':{'base':'https://api.openai.com/v1','model':'gpt-4o-mini','key':'OPENAI_API_KEY'},
 'nvidia':{'base':'https://integrate.api.nvidia.com/v1','model':'openai/gpt-oss-20b','key':'NVIDIA_API_KEY'},
}
def model_for(name,p): return os.getenv(f'LLM_MODEL_{name.upper()}') or os.getenv('LLM_MODEL') or p['model']
def base_for(name,p): return os.getenv(f'LLM_BASE_URL_{name.upper()}') or (os.getenv('NVIDIA_NIM_BASE_URL') if name=='nvidia' else None) or p['base']
def _prompt_evidence(evidence):
 """Bound provider context while retaining source and transformation provenance."""
 compact=[]
 for item in evidence:
  entry={k:v for k,v in item.items() if k!='records'}; records=item.get('records')
  entry['records']=records[:4] if isinstance(records,list) else records
  compact.append(entry)
 return json.dumps(compact,default=str,separators=(',',':'))[:14000]
def provider_status():
 name=os.getenv('LLM_PROVIDER','nvidia').lower(); p=PROVIDERS.get(name,PROVIDERS['nvidia']); return {'provider':name,'model':model_for(name,p),'base_url':base_for(name,p),'configured':bool(os.getenv(p['key'])),'providers':{k:{'configured':bool(os.getenv(v['key'])),'model':model_for(k,v),'base_url':base_for(k,v)} for k,v in PROVIDERS.items()}}
async def chat(question):
 name=os.getenv('LLM_PROVIDER','nvidia').lower(); p=PROVIDERS.get(name,PROVIDERS['nvidia']); key=os.getenv(p['key']); model=model_for(name,p)
 trace=AuditTrace('assistant',question,{'provider':name,'model':model})
 evidence=orchestrator.run(question,trace)
 if not key:
  with trace.span('llm_generation','ProviderAdapter',{'provider':name,'configured':False},{'purpose':'provider readiness check; no external call was made'}) as span: span.set_output(mode='local_fallback',reason='missing_api_key')
  evidence['audit']={**evidence['audit'],**trace.complete('degraded')}
  return {**evidence,'provider':name,'note':f'No {p["key"]} configured. Returned deterministic, dataset-grounded multi-agent insight.'}
 system=('You are SupplyMuse, a supply-chain risk analyst. Answer using only the supplied synthetic quick-commerce dataset evidence. Do not invent facts. Clearly state that the dataset is synthetic and intended for demonstration, not operational decisions. Keep response concise. Evidence JSON: '+_prompt_evidence(evidence['evidence']))
 headers={'Authorization':f'Bearer {key}','Content-Type':'application/json'}
 if name=='openrouter': headers.update({'HTTP-Referer':'http://localhost:5173','X-Title':'SupplyMuse Capstone'})
 payload={'model':model,'messages':[{'role':'system','content':system},{'role':'user','content':question}], 'temperature':float(os.getenv('LLM_TEMPERATURE','0.6' if name=='nvidia' else '0.2')),'max_tokens':int(os.getenv('LLM_MAX_TOKENS','1200' if name=='nvidia' else '650'))}
 try:
  with trace.span('llm_generation','ProviderAdapter',{'provider':name,'model':model,'base_url':base_for(name,p),'evidence_agents':evidence['routed_agents'],'question_length':len(question)},{'purpose':'grounded natural-language rendering; provider receives compact evidence only','guardrails':['No API key, raw question, or full dataset stored in audit log.','LLM output does not replace deterministic evidence.']}) as span:
   # A remote narrative is optional; never let it stall the local, grounded fallback.
   timeout=max(3,min(float(os.getenv('LLM_TIMEOUT_SECONDS','18')),40))
   async with httpx.AsyncClient(timeout=timeout) as client:
    r=await client.post(base_for(name,p).rstrip('/')+'/chat/completions',headers=headers,json=payload); r.raise_for_status(); data=r.json()
   span.set_output(http_status=r.status_code,response_model=data.get('model',model),choice_count=len(data.get('choices',[])))
  answer=data['choices'][0]['message'].get('content')
  if not answer: raise ValueError('Provider returned no final text content')
  evidence['audit']={**evidence['audit'],**trace.complete('ok')}
  return {'answer':answer,'evidence':evidence['evidence'],'agent_trace':evidence['agent_trace'],'routed_agents':evidence['routed_agents'],'audit':evidence['audit'],'mode':'llm','provider':name,'model':data.get('model',model)}
 except Exception as e:
  detail=f'HTTP {e.response.status_code}' if isinstance(e,httpx.HTTPStatusError) else type(e).__name__
  evidence['audit']={**evidence['audit'],**trace.complete('degraded',detail)}
  return {**evidence,'mode':'local_fallback','provider':name,'note':f'LLM request failed; returned local grounded analytics ({detail}). Check provider key/model/quota.'}
