"""Dataset access and reproducible supply-chain feature preparation."""
from functools import lru_cache
import hashlib
from pathlib import Path
import pandas as pd

BASE = Path(__file__).resolve().parents[1] / "data"
REQUIRED_ORDER_COLUMNS = {"order_id", "order_datetime", "store_id", "city", "sku_id", "supplier_id", "quantity", "order_value_inr", "order_status", "promised_delivery_minutes", "actual_delivery_minutes", "is_late", "is_stockout_substitute"}

@lru_cache(maxsize=None)
def load(name):
    path = BASE / f"{name}.csv"
    if not path.exists(): raise FileNotFoundError(f"Missing {path.name}; run python generate_quickcommerce_data.py to create the synthetic demo dataset.")
    return pd.read_csv(path)

def clear_cache():
    load.cache_clear(); prepared_orders.cache_clear(); data_lineage.cache_clear()

@lru_cache(maxsize=1)
def data_lineage():
    """Versioned data catalogue used in explanations and audit records."""
    names = ["orders", "products", "suppliers", "dark_stores", "inventory", "daily_demand", "inbound_shipments"]
    artifacts = []
    for name in names:
        path = BASE / f"{name}.csv"; raw = path.read_bytes()
        artifacts.append({"table": path.name, "rows": int(len(load(name))), "bytes": path.stat().st_size, "sha256": hashlib.sha256(raw).hexdigest()[:16]})
    version = hashlib.sha256("|".join(x["sha256"] for x in artifacts).encode()).hexdigest()[:16]
    return {"dataset_version": version, "artifacts": artifacts, "synthetic": True, "source": {"name": "SupplyMuse Synthetic Quick-Commerce Dataset", "generator": "backend/generate_quickcommerce_data.py", "seed": 20260930, "scope": "12,000 synthetic delivered orders across 15 Indian dark stores"}}

@lru_cache(maxsize=1)
def prepared_orders():
    """Return order lines with deterministic analytical features."""
    d = load("orders").copy(); missing = REQUIRED_ORDER_COLUMNS.difference(d.columns)
    if missing: raise ValueError(f"orders.csv schema is missing: {', '.join(sorted(missing))}")
    d["order_datetime"] = pd.to_datetime(d["order_datetime"], errors="coerce")
    if d["order_datetime"].isna().any(): raise ValueError("orders.csv has invalid order_datetime values")
    d["actual_delivery_minutes"] = pd.to_numeric(d["actual_delivery_minutes"], errors="coerce")
    d["delivery_delay_minutes"] = (d["actual_delivery_minutes"] - pd.to_numeric(d["promised_delivery_minutes"], errors="coerce")).clip(lower=0).fillna(0)
    d["date"] = d["order_datetime"].dt.normalize(); d["week"] = d["order_datetime"].dt.to_period("W").astype(str)
    d["day_of_week"] = d["order_datetime"].dt.dayofweek; d["hour"] = d["order_datetime"].dt.hour
    suppliers = load("suppliers")[["supplier_id", "avg_lead_time_days", "on_time_rate_pct", "quality_issue_rate_pct"]].copy()
    d = d.merge(suppliers, on="supplier_id", how="left", validate="many_to_one")
    d["avg_lead_time_days"] = d["avg_lead_time_days"].fillna(d["avg_lead_time_days"].median())
    d["on_time_rate_pct"] = d["on_time_rate_pct"].fillna(d["on_time_rate_pct"].median()); d["quality_issue_rate_pct"] = d["quality_issue_rate_pct"].fillna(0)
    freq = d.groupby(["supplier_id", "date"])["order_id"].nunique().rename("supplier_daily_orders")
    d = d.join(freq, on=["supplier_id", "date"]); d["supplier_order_frequency_z"] = d.groupby("supplier_id")["supplier_daily_orders"].transform(lambda s: (s - s.mean()) / (s.std(ddof=0) if s.std(ddof=0) else 1)).fillna(0)
    return d

def orders(): return prepared_orders().copy()

def quality_report():
    d = prepared_orders(); files = ["orders", "products", "suppliers", "dark_stores", "inventory", "daily_demand", "inbound_shipments"]
    numeric = d.select_dtypes(include="number")
    outliers = {col: int(((numeric[col] < numeric[col].quantile(.01)) | (numeric[col] > numeric[col].quantile(.99))).sum()) for col in ["delivery_delay_minutes", "quantity", "order_value_inr"] if col in numeric}
    return {"rows": int(len(d)), "columns": int(len(d.columns)), "missing_cells": int(d.isna().sum().sum()), "missing_by_column": {k: int(v) for k, v in d.isna().sum().items() if v}, "duplicate_rows": int(d.duplicated().sum()), "schema_valid": True, "required_columns": sorted(REQUIRED_ORDER_COLUMNS), "outliers_at_1_99_percentile": outliers, "synthetic": True, "files": {name: int(len(load(name))) for name in files}, "lineage": data_lineage(), "preprocessing": ["Generated deterministic synthetic quick-commerce orders, deliveries, suppliers, dark stores, and inventory snapshots.", "Validated the order schema and parsed order_datetime; invalid dates fail fast.", "Created date, week, day-of-week, hour, delivery delay and supplier daily-order-frequency features.", "Generated observed synthetic on-hand inventory and replenishment fields for scenario analysis."], "notes": ["This is synthetic demo data generated with a fixed seed. It is suitable for product demonstrations and testing, not real-world operational decisions."]}

def summary():
    d = orders(); delivered = d[d.order_status == "Delivered"]
    return {"dataset_name": "SupplyMuse Synthetic Quick-Commerce Dataset", "synthetic": True, "order_lines": int(len(d)), "unique_orders": int(d.order_id.nunique()), "revenue_inr": round(float(d.order_value_inr.sum()), 2), "late_orders": int(delivered.loc[delivered.is_late == 1, "order_id"].nunique()), "late_rate_pct": round(float(delivered.is_late.mean() * 100), 2), "avg_delivery_minutes": round(float(delivered.actual_delivery_minutes.mean()), 1), "avg_promised_minutes": round(float(delivered.promised_delivery_minutes.mean()), 1), "cities": int(d.city.nunique()), "stores": int(d.store_id.nunique()), "skus": int(d.sku_id.nunique()), "suppliers": int(d.supplier_id.nunique()), "stockout_substitution_rate_pct": round(float(d.is_stockout_substitute.mean() * 100), 2)}
