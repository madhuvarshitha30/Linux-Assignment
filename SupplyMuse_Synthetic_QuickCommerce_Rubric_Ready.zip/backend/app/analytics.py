"""Explainable risk, anomaly and baseline forecasting analytics."""
import numpy as np
import pandas as pd
from sklearn.linear_model import Ridge
from .data import data_lineage, load, orders

RISK_TAXONOMY = {
    "supplier_reliability": {"description": "Synthetic supplier late-delivery performance.", "threshold": ">= 15% late rate"},
    "delivery_delay": {"description": "Actual delivery exceeds the promised delivery time.", "threshold": ">= 15 minutes is severe"},
    "lead_time_volatility": {"description": "Supplier delivery-time variation relative to its peer history.", "threshold": "robust z-score >= 3.5"},
    "inventory_depletion": {"description": "Synthetic on-hand inventory is below its replenishment threshold.", "threshold": "cover below lead time"},
    "order_frequency_spike": {"description": "Supplier daily order volume is unusually high.", "threshold": "z-score >= 2.5"},
}
def _level(score): return np.select([score >= 65, score >= 35], ["High", "Medium"], default="Low")

def supplier_scorecards():
    d = orders(); delivered = d[d.order_status.eq("Delivered")].copy()
    g = delivered.groupby("supplier_id").agg(order_lines=("order_id", "count"), orders=("order_id", "nunique"), late_rate_pct=("is_late", "mean"), avg_delay_minutes=("delivery_delay_minutes", "mean"), delay_std_minutes=("delivery_delay_minutes", "std"), avg_lead_time_days=("avg_lead_time_days", "mean"), quality_issue_rate_pct=("quality_issue_rate_pct", "mean"), frequency_volatility=("supplier_order_frequency_z", lambda x: float(np.abs(x).mean()))).reset_index().fillna(0)
    g = g.merge(load("suppliers")[["supplier_id", "supplier_name", "supplier_region"]], on="supplier_id", how="left")
    inbound = load("inbound_shipments").groupby("supplier_id").agg(inbound_shipments=("shipment_id", "count"), inbound_late_rate=("is_late_receipt", "mean"), avg_inbound_lead_time_days=("actual_lead_time_days", "mean"), inbound_lead_time_std_days=("actual_lead_time_days", "std")).reset_index()
    g = g.merge(inbound, on="supplier_id", how="left").fillna(0)
    # Explicit 100-point model: reliability 35, delay 25, volatility 20, quality 10, demand variability 10.
    g["risk_score"] = ((g[["late_rate_pct", "inbound_late_rate"]].max(axis=1) * 100 / 30).clip(0, 1) * 35 + (g.avg_delay_minutes / 12).clip(0, 1) * 25 + (g.inbound_lead_time_std_days / 2).clip(0, 1) * 20 + (g.quality_issue_rate_pct / 8).clip(0, 1) * 10 + (g.frequency_volatility / 2).clip(0, 1) * 10).round(1)
    g["risk_level"] = _level(g.risk_score); g["late_rate_pct"] = (g.late_rate_pct * 100).round(1)
    return g.sort_values(["risk_score", "late_rate_pct"], ascending=False)

def _order_risk_data():
    d = orders().copy(); cards = supplier_scorecards().set_index("supplier_id")
    d["supplier_reliability_component"] = d.supplier_id.map(cards.risk_score).fillna(0) * .35
    d["delay_severity_component"] = (d.delivery_delay_minutes / 15).clip(0, 1) * 30
    med = d.groupby("supplier_id").delivery_delay_minutes.transform("median")
    mad = d.groupby("supplier_id").delivery_delay_minutes.transform(lambda s: np.median(np.abs(s - np.median(s))))
    d["lead_time_robust_z"] = (0.6745 * (d.delivery_delay_minutes - med) / mad.replace(0, np.nan)).abs().fillna(0)
    d["lead_time_volatility_component"] = (d.lead_time_robust_z / 3.5).clip(0, 1) * 15
    d["stockout_component"] = d.is_stockout_substitute.fillna(0).astype(float) * 15
    d["frequency_component"] = (d.supplier_order_frequency_z.abs() / 2.5).clip(0, 1) * 5
    d["risk_score"] = (d.supplier_reliability_component + d.delay_severity_component + d.lead_time_volatility_component + d.stockout_component + d.frequency_component).clip(0, 100).round().astype(int); d["risk_level"] = _level(d.risk_score)
    return d

def trends():
    d = orders(); g = d.groupby("date").agg(orders=("order_id", "nunique"), revenue=("order_value_inr", "sum"), units=("quantity", "sum"), late_rate=("is_late", "mean")).reset_index(); g["day"] = g.date.dt.strftime("%Y-%m-%d"); g["late_rate"] = (g.late_rate * 100).round(1)
    return g[["day", "orders", "revenue", "units", "late_rate"]].to_dict("records")

def risk_rows(limit=300, search="", risk=""):
    d = _order_risk_data()
    if search: d = d[d.astype(str).apply(lambda c: c.str.contains(search, case=False, na=False)).any(axis=1)]
    if risk: d = d[d.risk_level.str.lower().eq(risk.lower())]
    cols = ["order_id", "order_datetime", "city", "area", "store_id", "sku_id", "product_name", "category", "supplier_id", "quantity", "order_value_inr", "order_status", "promised_delivery_minutes", "actual_delivery_minutes", "delivery_delay_minutes", "is_late", "is_stockout_substitute", "lead_time_robust_z", "risk_score", "risk_level"]
    return d.sort_values("risk_score", ascending=False)[cols].head(limit).fillna("").to_dict("records")

def order_explanation(order_id: str):
    """Return a decision card with feature contributions, thresholds and provenance."""
    d = _order_risk_data(); row = d[d.order_id.astype(str).eq(str(order_id))]
    if row.empty: return None
    r = row.iloc[0]; contributions = [
        {"factor": "Supplier reliability", "points": round(float(r.supplier_reliability_component), 1), "why": "Supplier scorecard combines historical lateness, delay variation, quality signals and order-volume volatility."},
        {"factor": "Delivery severity", "points": round(float(r.delay_severity_component), 1), "why": f"Observed delay is {r.delivery_delay_minutes:.1f} minutes; contribution caps at 15 minutes."},
        {"factor": "Lead-time anomaly", "points": round(float(r.lead_time_volatility_component), 1), "why": f"Supplier-specific robust z-score is {r.lead_time_robust_z:.2f}; anomaly threshold is 3.5."},
        {"factor": "Stockout substitution", "points": round(float(r.stockout_component), 1), "why": "Synthetic substitution events increase the review priority."},
        {"factor": "Order frequency variation", "points": round(float(r.frequency_component), 1), "why": f"Supplier daily-order z-score is {r.supplier_order_frequency_z:.2f}; contribution caps at 2.5."},
    ]
    return {"decision": {"order_id": r.order_id, "supplier_id": r.supplier_id, "product": r.product_name, "risk_score": int(r.risk_score), "risk_level": r.risk_level, "thresholds": {"High": ">=65", "Medium": "35-64", "Low": "<35"}}, "contributions": contributions, "provenance": {"sources": ["synthetic quick-commerce orders, delivery, supplier and inventory records"], "transformations": ["weighted risk scoring", "supplier-level aggregates", "median absolute deviation anomaly score"], **data_lineage()}, "limitations": ["The dataset is synthetic and intended for demonstration, not operational decisions.", "A risk score prioritizes review; it does not establish root cause or predict a calibrated probability."]}

def inventory_rows(limit=500):
    d = load("inventory").copy(); d["replenishment_gap_days"] = (d.lead_time_days - d.days_of_cover).round(2)
    d["inventory_risk_score"] = ((d.replenishment_gap_days.clip(lower=0) / d.lead_time_days.clip(lower=1)) * 70 + (d.on_hand_units < d.reorder_point_units).astype(int) * 30).clip(0, 100).round().astype(int)
    d["demand_proxy_risk"] = d["stockout_risk"].astype(str)
    return d.sort_values(["inventory_risk_score", "days_of_cover"], ascending=[False, True]).head(limit).to_dict("records")

def stock_summary():
    d = pd.DataFrame(inventory_rows(3000))
    return {"sku_store_records": len(d), "inventory_available": True, "high_risk": int((d.stockout_risk == "High").sum()), "medium_risk": int((d.stockout_risk == "Medium").sum()), "low_risk": int((d.stockout_risk == "Low").sum()), "low_cover_records": int((d.days_of_cover < 1).sum()), "items": d.head(40).to_dict("records")}

def group(field):
    d = _order_risk_data(); g = d.groupby(field).agg(order_lines=("order_id", "count"), orders=("order_id", "nunique"), revenue_inr=("order_value_inr", "sum"), late_rate_pct=("is_late", "mean"), avg_delivery_min=("actual_delivery_minutes", "mean"), avg_risk_score=("risk_score", "mean")).reset_index().rename(columns={field: "name"}); g.late_rate_pct = (g.late_rate_pct * 100).round(1); g.revenue_inr = g.revenue_inr.round(2); g.avg_delivery_min = g.avg_delivery_min.round(1); g.avg_risk_score = g.avg_risk_score.round(1)
    return g.sort_values("avg_risk_score", ascending=False).fillna(0).to_dict("records")

def anomalies(limit=100):
    d = _order_risk_data(); items = []
    shipments = load("inbound_shipments").copy(); shipment_med = shipments.groupby("supplier_id").actual_lead_time_days.transform("median"); shipment_mad = shipments.groupby("supplier_id").actual_lead_time_days.transform(lambda s: np.median(np.abs(s-np.median(s))))
    shipments["robust_z"] = (0.6745*(shipments.actual_lead_time_days-shipment_med)/shipment_mad.replace(0,np.nan)).abs().fillna(0)
    for _, r in shipments[shipments.robust_z >= 3.5].sort_values("robust_z", ascending=False).head(limit).iterrows():
        items.append({"type": "Inbound lead-time outlier", "severity": "High" if r.robust_z >= 5 else "Medium", "entity": r.supplier_id, "affected": r.shipment_id, "date": str(r.actual_receipt_date), "observed": float(r.actual_lead_time_days), "baseline": "supplier shipment median", "score": round(float(r.robust_z), 2), "evidence": f"Inbound shipment lead time of {r.actual_lead_time_days} days is unusual for this supplier"})
    for _, r in d[d.lead_time_robust_z >= 3.5].sort_values("lead_time_robust_z", ascending=False).head(limit).iterrows():
        items.append({"type": "Lead-time outlier", "severity": "High" if r.lead_time_robust_z >= 5 else "Medium", "entity": r.supplier_id, "affected": r.order_id, "date": r.order_datetime.strftime("%Y-%m-%d"), "observed": round(float(r.delivery_delay_minutes), 1), "baseline": "supplier median", "score": round(float(r.lead_time_robust_z), 2), "evidence": f"{r.delivery_delay_minutes:.0f} minutes late versus supplier-specific delivery history"})
    daily = d.groupby(["supplier_id", "date"]).order_id.nunique().rename("orders").reset_index(); daily["z"] = daily.groupby("supplier_id").orders.transform(lambda s: (s - s.mean()) / (s.std(ddof=0) if s.std(ddof=0) else 1))
    for _, r in daily[daily.z >= 2.5].sort_values("z", ascending=False).head(limit).iterrows():
        items.append({"type": "Order-frequency spike", "severity": "High" if r.z >= 3.5 else "Medium", "entity": r.supplier_id, "affected": f"{int(r.orders)} orders", "date": r.date.strftime("%Y-%m-%d"), "observed": int(r.orders), "baseline": "supplier daily mean", "score": round(float(r.z), 2), "evidence": "Demand volume is statistically unusual for this supplier"})
    inv = pd.DataFrame(inventory_rows(3000));
    observed_inventory = inv[inv.stockout_risk.isin(["High", "Medium", "Low"])]
    for _, r in observed_inventory[observed_inventory.replenishment_gap_days > 0].head(limit).iterrows():
        items.append({"type": "Inventory shortfall", "severity": "High" if r.stockout_risk == "High" else "Medium", "entity": r.supplier_id, "affected": f"{r.sku_id} / {r.store_id}", "date": str(r.snapshot_date), "observed": float(r.days_of_cover), "baseline": f"{r.lead_time_days} day lead time", "score": int(r.inventory_risk_score), "evidence": "Inventory cover is below replenishment lead time"})
    ranked = sorted(items, key=lambda x: (x["severity"] == "High", x["score"]), reverse=True)
    # Preserve at least one representative alert per detector in compact API responses.
    representatives = []
    for item in ranked:
        if item["type"] not in {x["type"] for x in representatives}: representatives.append(item)
    return (representatives + [x for x in ranked if x not in representatives])[:limit]

def forecast(horizon=14):
    """Train a regularized regression forecast with chronological holdout evaluation."""
    d = orders().groupby("date").quantity.sum().sort_index().astype(float); n_test = max(14, int(len(d) * .2)); train, test = d.iloc[:-n_test], d.iloc[-n_test:]; origin = d.index.min()
    def features(dates):
        idx = pd.DatetimeIndex(dates); day = (idx - origin).days.to_numpy(dtype=float)
        frame = {"trend": day, "trend_sq": day**2 / 100, "sin_week": np.sin(2*np.pi*day/7), "cos_week": np.cos(2*np.pi*day/7)}
        for dow in range(6): frame[f"dow_{dow}"] = (idx.dayofweek == dow).astype(float)
        return pd.DataFrame(frame)
    model = Ridge(alpha=8.0).fit(features(train.index), train.to_numpy())
    test_pred = np.clip(model.predict(features(test.index)), 0, None); err = test.to_numpy() - test_pred
    metrics = {"mae": round(float(np.abs(err).mean()), 2), "rmse": round(float(np.sqrt(np.mean(err ** 2))), 2), "mape": round(float((np.abs(err) / np.maximum(test.to_numpy(), 1)).mean() * 100), 2), "training_days": int(len(train)), "validation_days": int(len(test))}
    final_model = Ridge(alpha=8.0).fit(features(d.index), d.to_numpy()); future_dates = pd.date_range(d.index.max() + pd.Timedelta(days=1), periods=max(1, min(int(horizon), 60)), freq="D"); future_pred = np.clip(final_model.predict(features(future_dates)), 0, None)
    hist = [{"date": x.strftime("%Y-%m-%d"), "actual_units": round(float(y), 1), "forecast_units": None, "kind": "history"} for x, y in d.tail(45).items()]; future = [{"date": x.strftime("%Y-%m-%d"), "actual_units": None, "forecast_units": round(float(y), 1), "kind": "forecast"} for x, y in zip(future_dates, future_pred)]
    coefficients = {name: round(float(value), 4) for name, value in zip(features(d.index).columns, final_model.coef_)}
    return {"model": "Trained Ridge regression (trend + weekly seasonality)", "model_version": "ridge-v1", "target": "daily units sold", "horizon_days": len(future), "metrics": metrics, "series": hist + future, "explainability": {"features": list(coefficients), "coefficients": coefficients, "intercept": round(float(final_model.intercept_), 4), "training_window": {"start": train.index.min().strftime("%Y-%m-%d"), "end": train.index.max().strftime("%Y-%m-%d"), "observations": len(train)}, "validation_window": {"start": test.index.min().strftime("%Y-%m-%d"), "end": test.index.max().strftime("%Y-%m-%d"), "observations": len(test)}, "data_lineage": data_lineage()}, "methodology": "A Ridge regression is trained on time trend and weekly seasonality features. The final chronological 20% is held out for MAE, RMSE and MAPE; after evaluation, the model is refit on all available history for future predictions."}

def risk_report():
    cards = supplier_scorecards(); inv = pd.DataFrame(inventory_rows(3000)); risks = _order_risk_data()
    products = risks.groupby(["sku_id", "product_name", "supplier_id"]).agg(affected_orders=("order_id", "nunique"), average_risk=("risk_score", "mean"), late_rate=("is_late", "mean")).reset_index(); products["late_rate"] = (products.late_rate * 100).round(1); products.average_risk = products.average_risk.round(1)
    headline = f"{int((cards.risk_level == 'High').sum())} synthetic suppliers have high delivery risk."
    return {"headline": headline, "risk_model": {"name": "Explainable weighted operational risk score", "weights": {"supplier_delivery_history": 35, "delay_severity": 30, "lead_time_volatility": 15, "stockout_signal": 15, "order_frequency_variance": 5}, "levels": {"High": ">=65", "Medium": "35-64", "Low": "<35"}}, "top_suppliers": cards.head(8).replace({np.nan: None}).to_dict("records"), "affected_products": products.sort_values(["average_risk", "affected_orders"], ascending=False).head(12).to_dict("records"), "inventory_shortfalls": inv[inv.stockout_risk.isin(["High", "Medium"])].head(12).to_dict("records"), "anomalies": anomalies(20), "recommended_actions": ["Review high-risk suppliers and investigate late-rate, delay volatility, and volume spikes.", "Monitor delivery-time outliers before changing customer commitments; anomalies are alerts, not proof of root cause.", "Review low-cover inventory before replenishment lead time is exceeded."]}

def supply_chain_simulation(supplier_id: str | None = None, delay_days: int = 0, demand_multiplier: float = 1.0, horizon: int = 14):
    """Deterministic what-if simulation of supplier replenishment and store fulfilment.

    It does not alter CSV data. Baseline and scenario use the same initial inventory;
    only receipt timing and demand pressure differ, making the comparison reproducible.
    """
    delay_days = max(0, min(int(delay_days), 21)); horizon = max(3, min(int(horizon), 30)); demand_multiplier = float(np.clip(demand_multiplier, .5, 2.0))
    scorecards = supplier_scorecards(); selected = supplier_id if supplier_id in set(scorecards.supplier_id) else scorecards.iloc[0].supplier_id
    supplier = scorecards[scorecards.supplier_id.eq(selected)].iloc[0]
    inv = load("inventory").copy(); scope = inv[inv.supplier_id.eq(selected)].copy()
    if scope.empty: scope = inv.copy()
    scope["daily_demand"] = scope.avg_daily_demand_units.astype(float) * demand_multiplier
    scope["baseline_receipt_day"] = scope.lead_time_days.astype(int).clip(lower=1, upper=horizon + 1)
    scope["scenario_receipt_day"] = (scope.baseline_receipt_day + delay_days).clip(upper=horizon + 1)
    scope["replenishment_units"] = np.maximum(scope.reorder_point_units * 2, np.ceil(scope.daily_demand * (scope.lead_time_days + 3))).astype(float)

    def run(receipt_column):
        on_hand = scope.on_hand_units.astype(float).to_numpy().copy(); received = np.zeros(len(scope), dtype=bool); result = []; stockout_days = np.zeros(len(scope), dtype=int)
        total_demand = float(scope.daily_demand.sum())
        for day in range(1, horizon + 1):
            arriving = (~received) & (scope[receipt_column].to_numpy() == day)
            on_hand[arriving] += scope.replenishment_units.to_numpy()[arriving]; received[arriving] = True
            fulfilled = np.minimum(on_hand, scope.daily_demand.to_numpy()); on_hand -= fulfilled
            stockout_days += (on_hand <= 0.01)
            result.append({"day": day, "service_level_pct": round(float(fulfilled.sum() / max(total_demand, 1) * 100), 1), "on_hand_units": int(round(on_hand.sum())), "stockout_sku_stores": int((on_hand <= .01).sum()), "receiving_sku_stores": int(arriving.sum())})
        return result, on_hand, stockout_days

    baseline, baseline_stock, baseline_stockout_days = run("baseline_receipt_day")
    scenario, scenario_stock, scenario_stockout_days = run("scenario_receipt_day")
    timeline = []
    for b, sc in zip(baseline, scenario):
        timeline.append({"day": b["day"], "baseline_service_pct": b["service_level_pct"], "scenario_service_pct": sc["service_level_pct"], "baseline_on_hand": b["on_hand_units"], "scenario_on_hand": sc["on_hand_units"], "baseline_stockouts": b["stockout_sku_stores"], "scenario_stockouts": sc["stockout_sku_stores"], "receiving": sc["receiving_sku_stores"]})
    scope["baseline_ending_stock"] = baseline_stock; scope["scenario_ending_stock"] = scenario_stock; scope["additional_stockout_days"] = scenario_stockout_days - baseline_stockout_days
    affected = scope[scope.additional_stockout_days > 0].sort_values(["additional_stockout_days", "daily_demand"], ascending=False).head(12)
    impact = {"baseline_average_service_pct": round(float(np.mean([x["service_level_pct"] for x in baseline])), 1), "scenario_average_service_pct": round(float(np.mean([x["service_level_pct"] for x in scenario])), 1), "service_level_delta_points": round(float(np.mean([x["service_level_pct"] for x in scenario]) - np.mean([x["service_level_pct"] for x in baseline])), 1), "baseline_final_stockouts": baseline[-1]["stockout_sku_stores"], "scenario_final_stockouts": scenario[-1]["stockout_sku_stores"], "additional_stockout_days": int(scope.additional_stockout_days.clip(lower=0).sum()), "delayed_receipt_days": delay_days}
    cities = scope.groupby("city").agg(sku_store_records=("sku_id", "count"), starting_units=("on_hand_units", "sum"), daily_demand=("daily_demand", "sum")).reset_index().sort_values("daily_demand", ascending=False).head(6)
    events = [{"day": 1, "stage": "Supplier", "message": f"{selected} releases replenishment for {len(scope)} SKU-store records."}, {"day": int(scope.baseline_receipt_day.min()), "stage": "Inbound transport", "message": "Baseline replenishment begins arriving at stores."}]
    if delay_days: events.append({"day": int(scope.scenario_receipt_day.min()), "stage": "Disruption", "message": f"Scenario receipts arrive {delay_days} day(s) later than baseline."})
    events.append({"day": horizon, "stage": "Store fulfilment", "message": f"Scenario closes with {impact['scenario_final_stockouts']} stockout SKU-store records."})
    return {"simulation_id": f"sim-{selected.lower()}-{delay_days}d-{int(demand_multiplier*100)}x-{horizon}d", "assumptions": ["Simulation is deterministic and read-only; it never modifies source data.", "Starting inventory is a synthetic on-hand snapshot.", "Daily demand uses the synthetic 28-day demand rate multiplied by the selected demand scenario.", "Service level is a what-if indicator, not a production SLA."], "parameters": {"supplier_id": selected, "supplier_name": supplier.supplier_name, "supplier_risk_level": supplier.risk_level, "delay_days": delay_days, "demand_multiplier": demand_multiplier, "horizon_days": horizon}, "network": {"supplier": {"id": selected, "name": supplier.supplier_name, "risk_score": float(supplier.risk_score), "risk_level": supplier.risk_level, "lead_time_days": round(float(supplier.avg_inbound_lead_time_days), 1)}, "stores_by_city": cities.to_dict("records"), "sku_store_scope": int(len(scope)), "planned_replenishment_units": int(scope.replenishment_units.sum())}, "impact": impact, "timeline": timeline, "events": events, "affected_sku_stores": affected[["sku_id", "product_name", "store_id", "city", "on_hand_units", "daily_demand", "lead_time_days", "additional_stockout_days", "baseline_ending_stock", "scenario_ending_stock"]].to_dict("records"), "explainability": {"causal_chain": ["A supplier delay shifts the modeled receipt date.", "On-hand inventory is consumed while replenishment is in transit.", "Records with lower cover than the new receipt date receive more modeled stockout days.", "Reduced available inventory lowers simulated fulfillment service."], "provenance": {"sources": ["synthetic quick-commerce orders, inventory and shipment records"], **data_lineage()}, "limitations": ["The scenario does not model purchase orders, cross-store transfers, substitutions, or capacity.", "All underlying values are synthetic and intended for demonstration only."]}}
def knowledge_base(): return RISK_TAXONOMY
