"""Specialist agents with explicit handoffs, explanations and audit spans."""
from dataclasses import asdict, dataclass
from typing import Any
from .analytics import anomalies, forecast, inventory_rows, risk_report, supplier_scorecards
from .audit import AuditTrace
from .data import data_lineage, summary

@dataclass
class Evidence:
    agent: str
    stage: str
    source: str
    transformation: str
    finding: str
    explanation: dict[str, Any]
    records: Any

class SupplierRiskAgent:
    name = "SupplierRiskAgent"
    def run(self, question):
        rows = supplier_scorecards().head(6).to_dict("records")
        return Evidence(self.name, "supplier_assessment", "synthetic orders + supplier records", "supplier aggregation and transparent delivery-risk score", "Synthetic suppliers are ranked by late rate, delay variability, and order-volume volatility.", {"decision_rule": "High risk >=65; medium 35-64.", "inputs": ["late rate", "average delay", "delivery-time volatility", "order-frequency volatility"], "limitation": "This synthetic demo supports product testing, not real supplier assessment."}, rows)

class DeliveryRiskAgent:
    name = "DeliveryRiskAgent"
    def run(self, question):
        rows = [x for x in anomalies(25) if "lead-time outlier" in x["type"].lower()][:8]
        return Evidence(self.name, "delivery_anomaly_detection", "orders.csv + inbound_shipments.csv", "supplier-specific median absolute deviation (robust z-score)", "Delivery alerts identify unusually large last-mile or inbound lead times relative to each supplier's own history.", {"decision_rule": "Robust z-score >=3.5 creates an alert.", "why_robust": "Median and median absolute deviation are less distorted by incident outliers than mean and standard deviation.", "limitation": "An anomaly is a review signal, not a root-cause diagnosis."}, rows)

class InventoryRiskAgent:
    name = "InventoryRiskAgent"
    def run(self, question):
        rows = inventory_rows(12)
        return Evidence(self.name, "inventory_assessment", "synthetic inventory + order records", "on-hand inventory compared with replenishment lead time", "Exposure rows identify synthetic inventory records with lower cover than replenishment lead time.", {"decision_rule": "High risk applies when synthetic inventory cover is below the replenishment threshold.", "inputs": ["on-hand units", "daily demand", "replenishment lead time"], "limitation": "The values are synthetic and should not be used as operational inventory facts."}, rows)

class DemandForecastAgent:
    name = "DemandForecastAgent"
    def run(self, question):
        result = forecast()
        return Evidence(self.name, "forecasting", "synthetic quick-commerce orders", "Ridge regression trained on trend and weekly-seasonality features with chronological holdout", f"Forecast MAE is {result['metrics']['mae']}; RMSE is {result['metrics']['rmse']}; MAPE is {result['metrics']['mape']}%.", {"model": result["model"], "features": result["explainability"]["features"], "validation": result["metrics"], "limitation": "Synthetic data does not represent real promotions, holidays, supplier capacity, or inventory."}, {"metrics": result["metrics"], "next_days": result["series"][-7:]})

class SupplyChainInsightAgent:
    name = "SupplyChainInsightAgent"
    def run(self, question, evidence):
        s = summary(); names = ", ".join(e.agent.replace("Agent", "") for e in evidence)
        return Evidence(self.name, "cross_risk_synthesis", "shared specialist evidence", "cross-risk synthesis without generating new metrics", f"Combined {names} findings against {s['unique_orders']:,} synthetic quick-commerce orders. Evidence is for demo triage, not operational causality.", {"upstream_agents": [e.agent for e in evidence], "guardrail": "Synthesis may only use upstream evidence; it does not introduce unsupported facts."}, {"evidence_count": len(evidence), "dataset_version": data_lineage()["dataset_version"]})

class RecommendationAgent:
    name = "RiskRecommendationAgent"
    def run(self, question, evidence):
        report = risk_report()
        return Evidence(self.name, "recommendation", "risk report + upstream evidence", "risk-to-action mapping", "Recommended actions are prioritized for replenishment, supplier review, and anomaly investigation.", {"basis": "Recommendations are generated from reported risk categories and are not autonomous operational actions.", "review_required": True}, report["recommended_actions"])

class RiskOrchestrator:
    """Routes by intent and records each specialist handoff as an audit event."""
    def __init__(self):
        self.specialists = {"supplier": SupplierRiskAgent(), "delivery": DeliveryRiskAgent(), "inventory": InventoryRiskAgent(), "forecast": DemandForecastAgent()}
        self.insight, self.recommendation = SupplyChainInsightAgent(), RecommendationAgent()
    def route(self, question):
        q = question.lower(); selected = []
        mapping = {"supplier": ["supplier", "vendor", "reliability", "department", "fulfillment group"], "delivery": ["delivery", "delay", "late", "lead time"], "inventory": ["inventory", "stock", "sku", "availability", "product"], "forecast": ["forecast", "demand", "predict", "future"]}
        matched = {key: [term for term in terms if term in q] for key, terms in mapping.items()}
        for key, terms in matched.items():
            if terms: selected.append(key)
        return selected or ["supplier", "delivery", "inventory"], matched
    def _run_agent(self, agent, question, trace, upstream=None):
        input_meta = {"agent": agent.name, "upstream_agents": upstream or [], "dataset_version": data_lineage()["dataset_version"]}
        with trace.span("agent", agent.name, input_meta, {"purpose": "specialist analysis with a declared data source, method and limitation"}) as span:
            evidence = agent.run(question) if upstream is None else agent.run(question, upstream)
            span.set_output(stage=evidence.stage, source=evidence.source, transformation=evidence.transformation, record_count=len(evidence.records) if isinstance(evidence.records, list) else 1, explanation=evidence.explanation)
            return evidence
    def run(self, question, trace: AuditTrace | None = None):
        trace = trace or AuditTrace("assistant", question, {"dataset_version": data_lineage()["dataset_version"]})
        selected, matched = self.route(question)
        with trace.span("routing", "RiskOrchestrator", {"question_length": len(question), "dataset_version": data_lineage()["dataset_version"]}, {"routing_policy": "Keyword intent routing; no match uses supplier, delivery and inventory coverage."}) as span:
            span.set_output(selected_specialists=selected, matched_terms=matched)
        chain = [self._run_agent(self.specialists[key], question, trace) for key in selected]
        chain.append(self._run_agent(self.insight, question, trace, chain))
        chain.append(self._run_agent(self.recommendation, question, trace, chain))
        answer = " ".join(x.finding for x in chain[-2:])
        handoffs = [{"sequence": i + 1, "agent": x.agent, "stage": x.stage, "handoff_to": chain[i + 1].agent if i + 1 < len(chain) else None, "source": x.source, "transformation": x.transformation, "explanation": x.explanation} for i, x in enumerate(chain)]
        return {"answer": answer, "evidence": [asdict(x) for x in chain], "agent_trace": handoffs, "routed_agents": [x.agent for x in chain], "mode": "multi_agent_local", "audit": {"trace_id": trace.trace_id, "dataset_version": data_lineage()["dataset_version"], "privacy": "Question content is not persisted; only a SHA-256 fingerprint and length are logged."}}

orchestrator = RiskOrchestrator()
