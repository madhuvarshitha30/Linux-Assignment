"""Privacy-aware auditability and observability for SupplyMuse workflows."""
from __future__ import annotations
import hashlib
import json
import sqlite3
import time
import uuid
from contextlib import contextmanager
from datetime import datetime, timezone
from functools import lru_cache
from pathlib import Path
from typing import Any

AUDIT_DB = Path(__file__).resolve().parents[1] / "data" / "audit.db"

def _now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="milliseconds")

def fingerprint(value: Any) -> str:
    raw = value if isinstance(value, bytes) else json.dumps(value, sort_keys=True, default=str).encode("utf-8")
    return hashlib.sha256(raw).hexdigest()

def _compact(value: Any, limit: int = 1800) -> str:
    raw = json.dumps(value or {}, default=str, separators=(",", ":"))
    if len(raw) <= limit:
        return raw
    # Keep storage valid JSON even when an event has a large explanatory payload.
    return json.dumps({"truncated": True, "original_characters": len(raw), "preview": raw[:limit - 100]}, separators=(",", ":"))

@lru_cache(maxsize=1)
def _initialize_database() -> None:
    """Create the audit schema once per process, not once per API request."""
    AUDIT_DB.parent.mkdir(parents=True, exist_ok=True)
    with sqlite3.connect(AUDIT_DB, timeout=10) as con:
        con.execute("PRAGMA journal_mode=WAL")
        con.execute("""CREATE TABLE IF NOT EXISTS traces (
            trace_id TEXT PRIMARY KEY, created_at TEXT NOT NULL, completed_at TEXT,
            operation TEXT NOT NULL, status TEXT NOT NULL, duration_ms REAL,
            question_hash TEXT, question_length INTEGER, metadata TEXT, error_type TEXT
        )""")
        con.execute("""CREATE TABLE IF NOT EXISTS audit_events (
            event_id TEXT PRIMARY KEY, trace_id TEXT NOT NULL, parent_event_id TEXT,
            occurred_at TEXT NOT NULL, stage TEXT NOT NULL, component TEXT NOT NULL,
            status TEXT NOT NULL, duration_ms REAL, input_hash TEXT, input_metadata TEXT,
            output_metadata TEXT, explanation TEXT, error_type TEXT,
            FOREIGN KEY(trace_id) REFERENCES traces(trace_id)
        )""")
        con.execute("CREATE INDEX IF NOT EXISTS idx_audit_events_trace ON audit_events(trace_id, occurred_at)")
        con.execute("CREATE INDEX IF NOT EXISTS idx_traces_created ON traces(created_at DESC)")

def _connection() -> sqlite3.Connection:
    _initialize_database()
    con = sqlite3.connect(AUDIT_DB, timeout=10)
    con.row_factory = sqlite3.Row
    con.execute("PRAGMA busy_timeout=10000")
    return con

class AuditSpan:
    def __init__(self, trace: "AuditTrace", stage: str, component: str, input_metadata: dict | None = None, explanation: dict | None = None):
        self.trace, self.stage, self.component = trace, stage, component
        self.input_metadata, self.explanation = input_metadata or {}, explanation or {}
        self.event_id, self.started = str(uuid.uuid4()), time.perf_counter()
        self.output_metadata: dict = {}
    def set_output(self, **metadata: Any) -> None:
        self.output_metadata.update(metadata)
    def __enter__(self): return self
    def __exit__(self, exc_type, exc, tb):
        duration = round((time.perf_counter() - self.started) * 1000, 2)
        status = "error" if exc else "ok"; error_type = exc_type.__name__ if exc_type else None
        with _connection() as con:
            con.execute("""INSERT INTO audit_events VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?)""", (
                self.event_id, self.trace.trace_id, None, _now(), self.stage, self.component, status, duration,
                fingerprint(self.input_metadata), _compact(self.input_metadata), _compact(self.output_metadata),
                _compact(self.explanation), error_type,
            ))
        return False

class AuditTrace:
    """A trace never writes raw questions, secrets, prompts or full data rows to disk."""
    def __init__(self, operation: str, question: str | None = None, metadata: dict | None = None, trace_id: str | None = None):
        self.trace_id, self.operation, self.started = trace_id or str(uuid.uuid4()), operation, time.perf_counter()
        self.question_hash = fingerprint(question) if question else None; self.question_length = len(question) if question else None
        with _connection() as con:
            con.execute("INSERT OR REPLACE INTO traces(trace_id,created_at,operation,status,question_hash,question_length,metadata) VALUES(?,?,?,?,?,?,?)", (self.trace_id, _now(), operation, "running", self.question_hash, self.question_length, _compact(metadata)))
    def span(self, stage: str, component: str, input_metadata: dict | None = None, explanation: dict | None = None) -> AuditSpan:
        return AuditSpan(self, stage, component, input_metadata, explanation)
    def complete(self, status: str = "ok", error_type: str | None = None) -> dict:
        duration = round((time.perf_counter() - self.started) * 1000, 2)
        with _connection() as con:
            con.execute("UPDATE traces SET completed_at=?,status=?,duration_ms=?,error_type=? WHERE trace_id=?", (_now(), status, duration, error_type, self.trace_id))
        return {"trace_id": self.trace_id, "operation": self.operation, "status": status, "duration_ms": duration, "question_logged": False, "question_fingerprint": self.question_hash}

def record_api_request(method: str, path: str, status_code: int, duration_ms: float, request_id: str) -> None:
    trace = AuditTrace("api_request", metadata={"request_id": request_id, "method": method, "path": path})
    with trace.span("api", "FastAPI", {"method": method, "path": path}, {"purpose": "HTTP availability and latency monitoring"}) as span:
        span.set_output(status_code=status_code, request_id=request_id)
    trace.complete("ok" if status_code < 500 else "error")

def list_traces(limit: int = 50) -> list[dict]:
    with _connection() as con:
        rows = con.execute("SELECT trace_id,created_at,completed_at,operation,status,duration_ms,question_length,error_type FROM traces WHERE operation != 'api_request' ORDER BY created_at DESC LIMIT ?", (limit,)).fetchall()
    return [dict(row) for row in rows]

def trace_detail(trace_id: str) -> dict | None:
    with _connection() as con:
        trace = con.execute("SELECT trace_id,created_at,completed_at,operation,status,duration_ms,question_hash,question_length,metadata,error_type FROM traces WHERE trace_id=?", (trace_id,)).fetchone()
        events = con.execute("SELECT event_id,occurred_at,stage,component,status,duration_ms,input_hash,input_metadata,output_metadata,explanation,error_type FROM audit_events WHERE trace_id=? ORDER BY occurred_at", (trace_id,)).fetchall()
    if not trace: return None
    result = dict(trace); result["events"] = []
    for row in events:
        event = dict(row)
        for field in ("input_metadata", "output_metadata", "explanation"):
            try:
                event[field] = json.loads(event[field] or "{}")
            except json.JSONDecodeError:
                # Backward-compatible rendering for events written before safe truncation.
                event[field] = {"legacy_truncated_metadata": True, "preview": (event[field] or "")[:300]}
        result["events"].append(event)
    return result

def metrics() -> dict:
    with _connection() as con:
        totals = con.execute("SELECT COUNT(*) total_traces, SUM(CASE WHEN status='ok' THEN 1 ELSE 0 END) successful_traces, ROUND(AVG(duration_ms),2) avg_duration_ms FROM traces WHERE operation != 'api_request'").fetchone()
        stages = con.execute("SELECT stage,component,COUNT(*) count,ROUND(AVG(duration_ms),2) avg_duration_ms,SUM(CASE WHEN status='error' THEN 1 ELSE 0 END) errors FROM audit_events GROUP BY stage,component ORDER BY count DESC").fetchall()
        recent_errors = con.execute("SELECT trace_id,operation,created_at,error_type FROM traces WHERE status='error' ORDER BY created_at DESC LIMIT 10").fetchall()
    total = totals["total_traces"] or 0; success = totals["successful_traces"] or 0
    return {"storage": "SQLite WAL audit ledger", "privacy": "Raw questions, prompts, API keys and full evidence rows are not persisted.", "total_traces": total, "success_rate_pct": round(success / total * 100, 1) if total else 100.0, "average_trace_duration_ms": totals["avg_duration_ms"] or 0, "stage_metrics": [dict(x) for x in stages], "recent_errors": [dict(x) for x in recent_errors]}
