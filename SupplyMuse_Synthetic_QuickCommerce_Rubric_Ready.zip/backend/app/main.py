from dotenv import load_dotenv
load_dotenv()
import json, logging, time, uuid
from pathlib import Path
from fastapi import FastAPI,HTTPException,Query,Request
from fastapi.middleware.cors import CORSMiddleware
from .audit import list_traces,metrics,record_api_request,trace_detail
from .data import data_lineage,summary,quality_report
from .analytics import trends,risk_rows,inventory_rows,group,stock_summary,supplier_scorecards,anomalies,forecast,risk_report,knowledge_base,order_explanation,supply_chain_simulation
from .llm import chat,provider_status
app=FastAPI(title='SupplyMuse Supply Chain Intelligence',version='3.2.0',description='Synthetic quick-commerce analytics and AI decision support')
logger=logging.getLogger(__name__)
app.add_middleware(CORSMiddleware,allow_origins=['*'],allow_credentials=True,allow_methods=['*'],allow_headers=['*'])
@app.middleware('http')
async def observability_middleware(request:Request,call_next):
 request_id=request.headers.get('X-Request-ID',str(uuid.uuid4())); started=time.perf_counter()
 try:
  response=await call_next(request); status=response.status_code
 except Exception:
  status=500
  try: record_api_request(request.method,request.url.path,status,round((time.perf_counter()-started)*1000,2),request_id)
  except Exception: logger.exception('Could not record failed API request')
  raise
 response.headers['X-Request-ID']=request_id
 # Avoid auditing the audit-read endpoints themselves to prevent self-observation noise.
 if not request.url.path.startswith('/api/audit') and not request.url.path.startswith('/api/observability'):
  try: record_api_request(request.method,request.url.path,status,round((time.perf_counter()-started)*1000,2),request_id)
  except Exception: logger.exception('Could not record API request')
 return response
@app.get('/api/health')
def health(): return {'status':'ok','product':'SupplyMuse','dataset':'SupplyMuse Synthetic Quick-Commerce Dataset','orders':summary()['unique_orders']}
@app.get('/api/summary')
def get_summary(): return summary()
@app.get('/api/trends')
def get_trends(): return trends()
@app.get('/api/risks')
def get_risks(limit:int=Query(300,ge=1,le=3000),search:str='',risk:str=''): return risk_rows(limit,search,risk)
@app.get('/api/inventory')
def get_inventory(limit:int=Query(500,ge=1,le=3000)): return inventory_rows(limit)
@app.get('/api/stock-summary')
def get_stock_summary(): return stock_summary()
@app.get('/api/suppliers')
def get_suppliers(): return supplier_scorecards().fillna(0).to_dict('records')
@app.get('/api/categories')
def get_categories(): return group('category')
@app.get('/api/cities')
def get_cities(): return group('city')
@app.get('/api/quality')
def quality():
 return quality_report()
@app.get('/api/anomalies')
def get_anomalies(limit:int=Query(100,ge=1,le=500)): return anomalies(limit)
@app.get('/api/forecast')
def get_forecast(horizon:int=Query(14,ge=1,le=60)): return forecast(horizon)
@app.get('/api/risk-report')
def get_risk_report(): return risk_report()
@app.get('/api/risk-knowledge-base')
def get_risk_knowledge_base(): return knowledge_base()
@app.get('/api/simulation')
def simulation(supplier_id:str|None=None,delay_days:int=Query(0,ge=0,le=21),demand_multiplier:float=Query(1.0,ge=.5,le=2.0),horizon:int=Query(14,ge=3,le=30)):
 return supply_chain_simulation(supplier_id,delay_days,demand_multiplier,horizon)
@app.get('/api/explainability')
def explainability():
 return {'data_lineage':data_lineage(),'risk_taxonomy':knowledge_base(),'forecast':forecast(7)['explainability'],'audit_policy':{'storage':'backend/data/audit.db (SQLite WAL)','logs':'trace IDs, durations, source/transform summaries, model metadata and status','does_not_log':['raw questions','LLM prompts','API keys','full evidence rows']}}
@app.get('/api/explain/order/{order_id}')
def explain_order(order_id:str):
 result=order_explanation(order_id)
 if not result: raise HTTPException(status_code=404,detail='Order not found')
 return result
@app.get('/api/audit/traces')
def get_audit_traces(limit:int=Query(50,ge=1,le=200)): return {'traces':list_traces(limit)}
@app.get('/api/audit/traces/{trace_id}')
def get_audit_trace(trace_id:str):
 result=trace_detail(trace_id)
 if not result: raise HTTPException(status_code=404,detail='Audit trace not found')
 return result
@app.get('/api/observability/metrics')
def observability_metrics(): return metrics()
@app.get('/api/evaluation')
def evaluation_report():
    report_file=Path(__file__).resolve().parent.parent / 'data' / 'evaluation_report.json'
    if not report_file.exists():
        return {'status':'missing','message':'Evaluation report not generated yet. Run python evaluate.py from the backend folder.'}
    return json.loads(report_file.read_text(encoding='utf-8'))
@app.get('/api/llm/status')
def llm_status(): return provider_status()
@app.post('/api/assistant')
async def assistant(body:dict):
 q=str(body.get('question','')).strip()
 if len(q)<2: return {'answer':'Please enter a question.','evidence':[]}
 try: return await chat(q)
 except Exception:
  logger.exception('Assistant workflow failed')
  raise HTTPException(status_code=503,detail='The assistant is temporarily unavailable. Please retry.')
@app.get('/api/assistant')
async def assistant_get(q:str=Query(...,min_length=2)): return await chat(q)
