@echo off
setlocal
cd /d "%~dp0"

echo Starting SupplyMuse backend and frontend in separate terminals...
start "SupplyMuse Backend" cmd /k call "%~dp0backend\START_BACKEND.bat"
start "SupplyMuse Frontend" cmd /k call "%~dp0frontend\START_FRONTEND.bat"

echo.
echo Open http://localhost:5173 after both terminals report that they are ready.
