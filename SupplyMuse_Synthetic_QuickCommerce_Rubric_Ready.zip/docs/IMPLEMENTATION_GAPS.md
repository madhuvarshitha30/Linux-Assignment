# Final Rubric Traceability

SupplyMuse is aligned to the supplied AI-Powered Supply Chain Risk Intelligence Assistant brief using a fully synthetic quick-commerce dataset. The synthetic choice is intentional: it removes external-data dependency while preserving the required supplier, order, delivery, inventory, location, date, risk, anomaly, forecasting, and evidence relationships.

## Task 1 — Supply Chain Data Preparation & Risk Knowledge Base (20%)
- **Suppliers:** `backend/data/suppliers.csv`
- **Products/SKUs:** `backend/data/products.csv`
- **Orders:** `backend/data/orders.csv`
- **Deliveries:** delivery promise/actual/delay fields in orders plus `inbound_shipments.csv`
- **Inventory:** `backend/data/inventory.csv`
- **Locations/dark stores:** `backend/data/dark_stores.csv`
- **Dates/demand periods:** order timestamps and `daily_demand.csv`
- **Derived features:** late rate, delivery delay, lead time, order-frequency z-score, stockout/substitution signal, inventory cover, replenishment gap, supplier score, order risk score.
- **Quality checks:** schema checks, missing-value checks, duplicate checks, numeric/date validation and lineage metadata are exposed by the backend.
- **Knowledge base:** `/api/risk-knowledge-base` and the documented risk taxonomy/thresholds.

## Task 2 — Supplier Performance, Risk Detection & Forecasting (25%)
Implemented in `backend/app/analytics.py`.
- Supplier performance scorecards and risk levels.
- Recurring/late delivery analysis.
- Robust lead-time anomaly detection using supplier-level median/MAD.
- Order-frequency spike detection.
- Inventory shortfall/stockout risk.
- Affected products/orders are exposed through risk endpoints and the risk report.
- Explainable 100-point risk score with documented weights and thresholds.
- Demand forecasting uses Ridge regression with trend + weekly seasonality.
- Chronological holdout evaluation reports **MAE, RMSE and MAPE**.

## Task 3 — Multi-Agent Risk Intelligence & Decision Support (25%)
`backend/app/agents.py` contains the required specialist workflow:
1. SupplierRiskAgent
2. DeliveryRiskAgent
3. InventoryRiskAgent
4. DemandForecastAgent
5. SupplyChainInsightAgent
6. RiskRecommendationAgent

The `RiskOrchestrator` routes questions, executes specialists, passes structured `Evidence` objects between agents, and records every handoff in the audit trace. This structured evidence envelope is the project's **A2A-style internal communication**; no external A2A protocol is required for this local microservice demonstration. Each evidence object contains source, transformation, finding, explanation and records.

## Task 4 — Evaluation, Risk Reporting & User Application (20%)
- Supplier-risk identification: evaluated through generated supplier scorecards and high-risk cases.
- Anomaly detection: evaluated through deterministic synthetic anomaly cases and alert outputs.
- Forecast accuracy: MAE/RMSE/MAPE are stored in `backend/data/evaluation_report.json`.
- Natural-language routing: benchmark questions verify specialist selection and audit events.
- Generated insight correctness: synthesis is constrained to upstream evidence and declared transformations.
- Evidence grounding: assistant responses return evidence objects and trace/provenance metadata.
- Frontend already exposes supplier performance, risks, inventory, forecasts, anomalies, natural-language assistant, risk report, evidence/audit views, and simulation.

## Task 5 — Architecture, Documentation & Demonstration (10%)
- `docs/ARCHITECTURE.md` — technical architecture.
- `docs/ARCHITECTURE.pdf` — submission-ready architecture diagram in PDF.
- `docs/DESIGN_AND_EVALUATION.md` — design decisions, trade-offs, scoring, models and evaluation.
- `docs/DATA_CLEANING_AND_AGENT_WORKFLOW.md` — data preparation and agent workflow.
- `docs/AUDITABILITY_OBSERVABILITY.md` — traceability and observability.
- `docs/SUPPLY_CHAIN_SIMULATION.md` — disruption scenario methodology.
- `presentation.md` — 10-minute panel presentation/demo guide.
- `README.md` — setup, usage, API and dataset documentation.

## Synthetic dataset definition
The application uses **only deterministic synthetic quick-commerce data**. No Kaggle, Accenture, DataCo, customer PII or real company records are required at runtime. The canonical generator is `backend/generate_quickcommerce_data.py`.

The current generated dataset contains approximately 12,000 order lines, 8 suppliers, 30 SKUs, 15 dark stores, 120 days of demand/order history, inbound shipment records and synthetic inventory snapshots. Fixed random seeds make regeneration reproducible.

## Known demonstration limitations
- Synthetic values are not operational facts.
- The risk score is a prioritization score, not a calibrated probability of failure.
- Forecast accuracy is measured on synthetic demand and should be regenerated if the seed/data generation logic changes.
- The assistant's language quality is not equivalent to human expert evaluation; the automated benchmark focuses on routing, evidence presence and traceability.
