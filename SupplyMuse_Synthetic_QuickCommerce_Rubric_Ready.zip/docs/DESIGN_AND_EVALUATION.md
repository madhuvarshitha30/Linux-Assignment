# SupplyMuse design and evaluation

See [ARCHITECTURE.md](ARCHITECTURE.md) for the current SupplyMuse architecture diagram.

## Scope and data preparation

SupplyMuse uses a reproducible synthetic quick-commerce dataset as a supply-chain logistics proxy. It includes supplier, product/SKU, order/delivery, inbound shipment, inventory, store/location, and daily demand records. The application is intentionally explicit that this is demonstration data, not a claim about a real retailer.

On load, the backend validates required order columns and parses dates. It joins supplier lead-time, reliability, and quality attributes; derives delivery delay, date/week/hour, and supplier daily-order frequency with a supplier-relative z-score. Inbound shipments explicitly retain planned and actual receipt dates and supplier-to-store lead times. Missing invalid dates fail fast. Delivery values for cancelled orders are not treated as observed delivery performance; a zero is used only in aggregate operational features. 1st/99th percentile outliers are reported but retained because unusual operations are the incidents worth investigating.

## Risk model and detection

Order-level risk is a transparent 100-point score:

| Signal | Weight | Interpretation |
| --- | ---: | --- |
| Supplier reliability | 35 | Historical scorecard based on late rate, delay variation, quality issues, and demand variability |
| Delay severity | 30 | Delay relative to a 15-minute severity cap |
| Lead-time volatility | 15 | Supplier-specific median absolute deviation / robust z-score |
| Stockout signal | 15 | Recorded simulated substitution signal |
| Frequency variance | 5 | Supplier daily-order volume relative to historical variation |

High risk is 65–100, medium is 35–64, and low is below 35. Anomalies are created for robust delivery z-scores of at least 3.5, supplier daily-order z-scores of at least 2.5, and inventory cases where days of cover are lower than replenishment lead time. These are alerts for investigation, not causal findings.

Supplier scorecards provide the risk inputs and product impact is aggregated from affected order rows. Inventory risk combines the replenishment gap and whether on-hand inventory has dropped below its reorder point.

## Forecasting

The forecast is a trained Ridge regression over time-trend, quadratic-trend, and weekly-seasonality features. The final chronological 20% of the series is withheld from training and evaluated with MAE, RMSE, and MAPE; after scoring, the model is refit on all history for future dates. The Forecasts page and `/api/forecast` expose both the series and metrics. A production deployment should compare this transparent model with models that incorporate promotions, weather, holidays, supplier capacity, and external demand signals.

## Multi-agent workflow and evidence

`RiskOrchestrator` routes a question to one or more specialists:

1. `SupplierRiskAgent` — supplier scorecards and reliability evidence.
2. `DeliveryRiskAgent` — lead-time outlier evidence.
3. `InventoryRiskAgent` — low-cover SKU-store evidence.
4. `DemandForecastAgent` — forecast and holdout metrics.
5. `SupplyChainInsightAgent` — combines the selected findings.
6. `RiskRecommendationAgent` — maps the synthesized risk report to actions.

Each handoff returns a structured evidence object containing the agent, source tables, transformation, finding, and records. The API returns both `evidence` and `agent_trace`; the dashboard can expose the entire chain. An optional LLM only turns this supplied evidence into prose and does not replace the deterministic analysis.

## Evaluation method

Run `python evaluate.py` from `backend/`. It writes `data/evaluation_report.json` and checks:

- schema/data-quality status;
- forecast MAE, RMSE, and MAPE from the chronological holdout;
- count and types of detected anomaly alerts;
- supplier risk scorecard coverage;
- routing of representative natural-language questions to the expected specialist;
- risk-report coverage and recommendation count.

For a real dataset, extend this with reviewed incident labels (precision/recall for anomaly and supplier-risk flags), backtesting across multiple cutoffs, and a human rubric for correctness, relevance, actionability, and evidence grounding of assistant responses.

## Trade-offs

The system favors traceability over opaque model complexity: CSV/Pandas transforms and baselines are easy to audit in a capstone review. The synthetic data supports complete demonstration flows but prevents claims of real-world model validity. The multi-agent pattern is local, deterministic and auditable; A2A is represented as explicit structured handoffs rather than independent network services, keeping local setup simple while preserving provenance.

## Digital-twin simulation

SupplyMuse includes a read-only, deterministic supplier-to-store disruption simulator. It holds initial stock constant between baseline and scenario, shifts replenishment receipt dates by a selected supplier delay, applies a demand multiplier, and reports the resulting service-level and stockout delta. It is designed for explanation and rehearsal rather than optimization. See [SUPPLY_CHAIN_SIMULATION.md](SUPPLY_CHAIN_SIMULATION.md) for flow, assumptions, API, and limitations.
