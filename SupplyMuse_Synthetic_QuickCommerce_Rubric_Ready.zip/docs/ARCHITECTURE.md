# SupplyMuse Architecture

This project is a full-stack supply-chain intelligence application built around a deterministic analytics layer, a multi-agent reasoning pipeline, and a browser-based decision dashboard. The design separates raw data ingestion, validated feature preparation, forecasting and risk analysis, explanation workflows, and user-facing UI concerns so the system remains auditable and explainable.

## System architecture diagram

```mermaid
flowchart TB
    U[User / operator] --> UI[frontend/src/main.jsx\nReact + Vite dashboard]
    UI --> API[backend/app/main.py\nFastAPI REST API]

    subgraph Frontend
        UI --> V1[Overview\nRisks\nInventory\nForecast\nAnomalies\nAudit\nAI Assistant]
    end

    subgraph Backend
        API --> D[backend/app/data.py\nSchema validation + data lineage + cached CSV access]
        D --> O[backend/data/*.csv\nPrepared analytical tables]
        O --> A[backend/app/analytics.py\nRisk scoring, anomalies, forecast, simulation]
        A --> AG[backend/app/agents.py\nSpecialist agents + orchestrator]
        AG --> L[backend/app/llm.py\nProvider adapter: NVIDIA / OpenAI / OpenRouter]
        AG --> AU[backend/app/audit.py\nSQLite WAL trace logging]
        AU --> API
        L --> API
    end

    subgraph Data Sources
        RAW[backend/generate_quickcommerce_data.py\nFixed-seed synthetic generator]
        IMP[backend/data/*.csv\nGenerated analysis tables]
        RAW --> IMP
        IMP --> O
    end

    subgraph External Services
        P[LLM provider\nOpenAI-compatible endpoint]
        L --> P
    end

    D --> QA[Data quality\nLineage\nDerived proxy warnings]
    QA --> API
    A --> R[Operational insight and recommendations]
    R --> AG
    AG --> E[Evidence, explanation, and audit trace]
    E --> API
    API --> UI
    UI --> U
```

## Stage-by-stage explanation

### 1. Raw data ingestion
The project begins with [backend/generate_quickcommerce_data.py](../backend/generate_quickcommerce_data.py). This fixed-seed generator is the **only dataset source** for the application and is the canonical source for all downstream synthetic analysis tables.

Key characteristics:
- It generates synthetic historical order, shipment, fulfilment, supplier, product, dark-store, inventory, and demand data.
- A fixed seed makes regeneration reproducible.
- The application treats generated CSVs as demonstration data and explicitly labels them synthetic.
- The system records dataset version and file hashes through the lineage logic in [backend/app/data.py](../backend/app/data.py).

### 2. Import pipeline and analytical table generation
The generation step is handled by [backend/generate_quickcommerce_data.py](../backend/generate_quickcommerce_data.py). It writes the project’s usable synthetic analytical tables to [backend/data](../backend/data).

This stage creates the reproducible application dataset for:
- orders
- products
- suppliers
- dark_stores
- inventory
- daily_demand
- inbound_shipments

There is no external/raw vendor dataset in the runtime project. The generated CSVs are the prepared analytical data consumed by the API and dashboard. This keeps the demo self-contained, reproducible, and explainable.

### 3. Data access and schema validation layer
The main data access layer lives in [backend/app/data.py](../backend/app/data.py).

This module is the backbone of the project because it:
- loads CSV tables with caching using `lru_cache`
- validates that required columns exist before analytics run
- parses and normalizes timestamps and numeric fields
- creates derived features such as delivery delay, date, week, day-of-week, and supplier frequency signals
- exposes a `quality_report()` for schema checks and data quality monitoring
- emits dataset lineage information and version hashes

This makes the analytics layer deterministic and prevents invalid or partial data from silently reaching the user interface.

### 4. Data quality and lineage checks
The project does not treat data as “just available.” It explicitly tracks quality and caveats.

The `quality_report()` function in [backend/app/data.py](../backend/app/data.py) returns:
- row and column counts
- missing-cell totals
- duplicate rows
- schema validity
- outlier statistics for key numeric fields
- dataset lineage metadata
- preprocessing notes and limitation statements

This stage is crucial for trust: the app explicitly labels every operational value as synthetic. Supplier performance, inventory position, shipment timing, and demand are generated demonstration signals rather than real operational records.

### 5. Core analytics engine
The heart of the operational intelligence is [backend/app/analytics.py](../backend/app/analytics.py).

This module calculates the project’s main outputs:

- `supplier_scorecards()`: weighted supplier risk scores from lateness, delay variance, quality signals, and frequency volatility
- `risk_rows()`: order-level risk register with severity and decision scoring
- `anomalies()`: outlier detection for lead-time shocks, volume spikes, and shortfall risk
- `forecast()`: daily demand prediction using a Ridge regression model with a chronological validation holdout
- `risk_report()`: executive summary with risk model weights and recommended actions
- `supply_chain_simulation()`: what-if scenario analysis for changed receipt days and demand pressure
- `order_explanation()`: interpretable decision cards showing how a score was built

This module is the decision engine: it turns raw data into interpretable operational signals.

### 6. Explainability and forecasting methodology
The analytics layer is intentionally transparent about how it reaches conclusions.

For example:
- risk scores are weighted and documented
- anomalies use robust z-score methods to avoid distortion from outliers
- the demand forecast uses trend and weekly seasonality features
- output includes the exact features and coefficients used in the forecast
- each explanation includes source and transformation metadata

This is a major architectural decision: the system does not rely on opaque “black-box” decisions. It produces a reasoning trail that can be inspected by both the dashboard and the audit system.

### 7. Specialist agent layer
The specialist reasoning layer is implemented in [backend/app/agents.py](../backend/app/agents.py).

Each agent has a clear, bounded responsibility:

- `SupplierRiskAgent`: evaluates delivery reliability and supplier proxy risk
- `DeliveryRiskAgent`: detects lead-time anomalies and unusual delays
- `InventoryRiskAgent`: reviews coverage and inventory exposure using the project’s documented demand proxy
- `DemandForecastAgent`: returns forecast evidence and validation metrics
- `SupplyChainInsightAgent`: synthesizes evidence across risk categories
- `RecommendationAgent`: maps findings to recommend actions

The `RiskOrchestrator` routes incoming user questions by intent keywords and executes the relevant specialist agents in sequence. It also creates structured handoff metadata so each stage is auditable.

This is the architecture that turns the analytics layer into a conversational decision assistant.

### 8. LLM rendering and provider abstraction
The natural-language response layer lives in [backend/app/llm.py](../backend/app/llm.py).

This layer:
- selects the configured provider (`nvidia`, `openai`, or `openrouter`)
- reads API keys from environment configuration
- builds grounded prompts using only compact evidence from the orchestrator
- sends the final answer request to an OpenAI-compatible LLM endpoint
- falls back to a deterministic local answer when no API key is configured or the provider call fails

This design is intentionally conservative:
- The system does not send raw questions or full dataset rows to the LLM.
- It sends a compact evidence snapshot only.
- The final answer is still grounded by the same analytics engine the dashboard uses.

### 9. API layer and control-tower surface
The external interface is defined in [backend/app/main.py](../backend/app/main.py).

This FastAPI app exposes endpoints for:
- health and summary
- delivery-risk, inventory, forecast, and anomaly views
- explainability and provenance queries
- audit and observability metrics
- LLM status checks
- the assistant question endpoint

It also includes an HTTP middleware that:
- assigns a request ID
- measures latency
- records request metadata in the audit ledger
- excludes sensitive audit endpoints from self-observation loops

The API is therefore both a data service and a monitoring boundary for the overall system.

### 10. Auditability and observability
The system’s trace system is implemented in [backend/app/audit.py](../backend/app/audit.py).

Key features:
- SQLite WAL storage for audit records
- trace IDs for each major workflow
- stage-level timing and status logging
- metadata hashing rather than storing raw values
- privacy-aware retention of only minimal metadata, not raw questions, prompts, secrets, or full result rows

This design is essential to the project’s “decision intelligence” goal: the user can inspect not just the outcome, but the operational path that created it.

### 11. Frontend dashboard and decision workspace
The browser experience lives in [frontend/src/main.jsx](../frontend/src/main.jsx).

It uses:
- React for the UI layer
- Vite for frontend bootstrapping and serving
- Recharts for charts and network visualization
- direct calls to the FastAPI backend endpoints

The dashboard includes views for:
- Overview
- Supply Simulation
- Agent Studio
- Delivery Risks
- Inventory
- Forecasts
- Anomalies
- Risk Report
- Supplier Scorecards
- AI Assistant
- Audit & Observability
- Data Quality

This creates a control-tower interface where operators can inspect the same signals the system uses to reason, not a separate reporting layer disconnected from the actual backend logic.

### 12. Runtime data flow across the system
At runtime, the project follows this flow:

1. The user asks a question or opens a dashboard view.
2. The frontend calls the appropriate API endpoint.
3. FastAPI routes the request to a deterministic analytics or agent function.
4. The analytics engine calculates the result from validated CSV data.
5. The orchestrator chooses relevant specialist agents when a question requires reasoning.
6. Each agent emits evidence with source, transformation, limitations, and explanation.
7. The LLM adapter produces a final natural-language interpretation from compact evidence.
8. The audit system records timing, status, and provenance without storing sensitive raw input.
9. The response is returned to the dashboard for display and investigation.

## Why this architecture fits the project

This architecture intentionally separates concerns:

- data ingestion is isolated from analytics
- validation is separate from decision logic
- explanation is separate from orchestration
- the UI is separate from the backend intelligence
- privacy and observability are enforced at the audit layer

That separation makes the project more trustworthy and easier to evaluate, especially in a supply-chain setting where risk models must be explainable and auditable.

## Related project docs

- [DESIGN_AND_EVALUATION.md](DESIGN_AND_EVALUATION.md): model, agent pipeline, and evaluation approach
- [AUDITABILITY_OBSERVABILITY.md](AUDITABILITY_OBSERVABILITY.md): trace/event schema and audit APIs
- [SUPPLY_CHAIN_SIMULATION.md](SUPPLY_CHAIN_SIMULATION.md): what-if disruption simulation details
