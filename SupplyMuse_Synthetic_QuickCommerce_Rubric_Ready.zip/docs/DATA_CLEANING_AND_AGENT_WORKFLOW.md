# Data Cleaning, Normalization, and AI Agent Workflow

This document explains the technical pipeline behind SupplyMuse: how deterministic synthetic quick-commerce data is generated, validated, and used by the AI agents to produce risk, forecast, and decision insights.

## 1. Data cleaning and normalization techniques

The application starts from raw supply-chain CSV files and transforms them into usable analytical tables that power the dashboard, forecasts, anomaly detection, and AI reasoning.

### 1.1 Synthetic source generation

The application uses generated CSVs under `backend/data/`; there is no external raw-data directory in the submission.

The pipeline reads source tables such as:
- orders
- suppliers
- products
- inventory
- shipping / inbound shipment records
- sales / demand data
- dark stores and city metadata

### 1.2 Column standardization

The cleaning process includes:
- validating the generated schemas and required fields
- converting mixed-case names into consistent identifiers
- normalizing date columns to a common datetime format
- aligning categorical values such as city, category, and supplier names
- removing noisy or non-essential fields before analytics

This makes downstream queries and joins consistent and predictable.

### 1.3 Missing-value treatment

The app handles missing values using controlled rules:
- missing timestamps are either dropped or backfilled if the business context allows it
- missing categorical values are mapped to a neutral or fallback label
- numerical blanks are replaced with safe defaults for scoring and alert generation
- incomplete records are flagged in the data quality report instead of silently disappearing

This is important because the project emphasizes evidence-based analytics and auditability.

### 1.4 Duplicate and invalid row handling

The pipeline protects the dataset from common data quality issues:
- duplicate rows are identified and removed where appropriate
- invalid shipping or date combinations are filtered out during the preparatory stage
- mismatched identifiers are reconciled across tables before feature generation
- records with impossible business values are either excluded or marked for review

### 1.5 Type normalization

The data is normalized into analysis-friendly types:
- IDs are treated as strings or stable categorical identifiers
- dates are parsed as dates or datetimes
- numbers are cast to numeric values for calculations
- risk scores, percentages, and delay values are converted into metric-friendly forms

This is required before risk scoring, forecasting, and agent evaluation.

### 1.6 Feature construction

The backend creates derived features used in the dashboard and risk engine, such as:
- delivery delay minutes
- late-rate percentages
- forecast error metrics
- inventory cover days
- supplier performance score
- category and city-level demand patterns
- disruption severity indicators

These features are not just raw fields; they are engineered indicators useful for decision-making.

### 1.7 Data provenance and lineage

SupplyMuse keeps a record of where the data came from and how it was transformed:
- generated table used
- preprocessing steps applied
- derived metrics generated
- version metadata for the dataset

This is an essential part of the project’s auditability and explainability strategy.

### 1.8 Quality reporting

The app exposes a quality summary so that users can see:
- number of rows processed
- columns available
- missing cells
- duplicate rows
- schema / preprocessing observations
- data lineage and transformation steps

This is surfaced through the Data Quality experience in the dashboard.

---

## 2. Normalization for operational analytics

Normalization is done to make all decisions comparable across cities, products, suppliers, and channels.

### 2.1 Supplier performance normalization

Supplier-level metrics are normalized against observed patterns such as:
- late delivery rate
- inbound delay variability
- risk score ranges
- category-specific performance

This allows the system to compare different suppliers meaningfully even when they serve different regions or product groups.

### 2.2 Inventory risk normalization

Inventory exposure is normalized using measures like:
- days of cover
- stockout risk indicators
- reorder risk thresholds
- demand volatility proxies

This creates a common basis to rank low-coverage or risky inventory conditions.

### 2.3 Demand and forecast normalization

Demand forecasting uses normalized time-based and seasonality-sensitive signals:
- trend components
- expected demand movements
- comparison of forecast vs observed values
- error metrics like MAE / RMSE / MAPE

This helps the model detect whether an operational issue is caused by supply disruption or by shifting demand.

### 2.4 Risk score scaling

Risk scores are normalized to a consistent range so they can be interpreted by the UI and the AI agent layer.

Examples:
- low / medium / high severity bands
- supplier risk classification
- operational alert severity levels
- disruption impact score

This keeps the backend and frontend aligned.

---

## 3. How the AI agents work

The app uses a multi-agent design where different agents focus on different parts of the supply-chain story. Each agent contributes a specialized perspective, and then an orchestrator combines them into a final decision-ready answer.

### 3.1 Overview of agent design

The AI layer includes specialist agents such as:
- Supplier Risk Agent
- Delivery Risk Agent
- Inventory Risk Agent
- Demand Forecast Agent
- Supply Chain Insight Agent
- Recommendation Agent
- Orchestrator / Risk Coordinator

These agents are implemented in `backend/app/agents.py` and connected to the analytics and data layers.

### 3.2 Supplier Risk Agent

Purpose:
- review supplier stability
- assess late-rate patterns
- estimate supplier risk level
- highlight vendors needing management review

What it uses:
- supplier records
- late shipment patterns
- risk score data
- historical delivery performance

Output:
- supplier reliability assessment
- risk flags
- prioritization for operational follow-up

### 3.3 Delivery Risk Agent

Purpose:
- detect delays and late order risk
- find patterns in routing or shipping disruption
- identify at-risk orders or shipments

What it uses:
- order timestamps
- promised vs actual delivery windows
- city and route metadata
- delay metrics from analytics

Output:
- risk register entries
- high-risk shipment lists
- timing-based anomaly summaries

### 3.4 Inventory Risk Agent

Purpose:
- estimate stock pressure
- identify inventory coverage problems
- detect low-cover or high-risk SKU situations

What it uses:
- inventory cover metrics
- reorder assumptions
- historical demand proxies
- days-of-cover calculations

Output:
- shortage exposure warnings
- stockout-risk signals
- operational recommendations

### 3.5 Demand Forecast Agent

Purpose:
- analyze future demand trends
- compare forecasted vs actual demand
- identify when demand changes may create operational strain

What it uses:
- demand trends
- historical demand series
- forecast model metrics
- feature-based predictions

Output:
- forecast summaries
- risk explanations tied to changing demand
- guidance for planning decisions

### 3.6 Supply Chain Insight Agent

Purpose:
- connect separate signals from suppliers, delivery, inventory, and demand
- synthesize the story behind an operational problem
- explain cause-and-effect relationships

What it uses:
- outputs from other agents
- analytics summaries
- risk flags and unusual patterns

Output:
- coherent explanation of the issue
- multi-factor reasoning report
- merged narrative for the dashboard or assistant

### 3.7 Recommendation Agent

Purpose:
- turn detected risks into action steps
- propose mitigation options and intervention suggestions

What it uses:
- anomaly alerts
- risk scores
- supplier and inventory state
- policy-like operational guidance

Output:
- recommended actions
- mitigation list
- decision support for users

### 3.8 Orchestrator / Coordinator

Purpose:
- route the question to the right agents
- collect partial findings
- merge them into one structured final answer
- ensure the final explanation stays grounded in the dataset

This is the controlling layer. It decides which agents matter for the current task and prevents the system from answering without evidence.

---

## 4. How the agents work together in practice

A typical workflow looks like this:

1. A user asks a question in the AI assistant, such as:
   - Which suppliers are at risk?
   - Where are inventory gaps appearing?
   - What is causing forecast volatility?
   - Which orders are likely to miss service goals?

2. The backend receives the question through the assistant endpoint.

3. The orchestrator routes the task to relevant agents.

4. The specialist agents inspect their data slices and return findings.

5. The insight agent combines those outputs into a coherent explanation.

6. The recommendation agent suggests decisions or actions.

7. The final response is returned to the frontend with evidence, trace metadata, and audit references.

This design makes the assistant not just conversational, but also grounded in operational analytics.

---

## 5. Why this architecture matters

This design keeps the app explainable and practical:
- data is cleaned and normalized before use
- risk logic remains traceable and auditable
- agents specialize in specific operational domains
- final answers are synthesized using multiple evidence sources
- the dashboard reflects real decision support rather than pure generative output

In short, the project is built around a layered approach:

Data -> Cleaning + normalization -> Analytics -> Agent reasoning -> AI assistant -> Decision support

---

## 6. Files involved

Main implementation points:
- `backend/app/data.py` — data ingestion and cleaning logic
- `backend/app/analytics.py` — risk and forecast calculations
- `backend/app/agents.py` — specialist agents and orchestration logic
- `backend/app/llm.py` — AI provider abstraction and fallback logic
- `backend/app/audit.py` — observability and trace tracking
- `backend/app/main.py` — API entry point connecting everything

This separation is important because it keeps the project modular, explainable, and easier to extend.

## Structured agent-to-agent handoff

The local multi-agent workflow uses a structured `Evidence` message as its A2A-style communication envelope. Each specialist returns the agent name, stage, source dataset, transformation, finding, explanation and evidence records. The orchestrator passes those messages to the Insight Agent and then to the Recommendation Agent. This provides explicit handoff and traceability without introducing an external protocol dependency.
