# SupplyMuse disruption simulation

The Supply Simulation screen is a deterministic, read-only digital-twin exercise. It compares baseline operations to a user-selected scenario without changing the CSV data, risk records, forecast, or audit history.

## Flow represented

```text
Supplier -> inbound transport -> receiving / replenishment -> city stores -> customer fulfilment
```

For a selected supplier, SupplyMuse scopes its SKU-store inventory records. Both paths begin with identical on-hand stock. The baseline receives one planned replenishment batch at each record's supplier lead time. The disruption path shifts the same receipt date by the chosen delay; demand can also be multiplied from 0.5x through 2.0x. On each simulated day the model receives eligible stock, fulfils demand from on-hand inventory, then measures service level and stockouts.

## Outputs

- daily baseline and scenario service levels;
- daily on-hand inventory and stockout SKU-store counts;
- affected SKU-store records and additional stockout days;
- selected supplier, scope, planned replenishment units, events, data version, assumptions, causal chain, and limitations.

The API is `GET /api/simulation?supplier_id=SUP001&delay_days=7&demand_multiplier=1.3&horizon=14`. Valid ranges are delay 0–21 days, demand 0.5x–2.0x, and horizon 3–30 days.

## Important limits

This is a capstone operational what-if, not a production optimization system. It does not create new purchase orders, model transfer decisions, simulate supplier capacity, model substitute products, or account for unrecorded in-transit inventory. Its role is to make the causal consequence of a delay visible and reviewable before a real planning decision is made.

## Agent Studio

The Agent Studio is an opt-in visual representation of the actual orchestration sequence: Supplier Risk, Delivery Risk, Inventory Risk, Demand Forecast, Insight, and Recommendation. It does not simulate independent autonomous workers; it visualizes the explicit, auditable specialist handoffs used by the backend. The AI Assistant and Audit & Observability screens provide the corresponding real trace IDs and stage records.
