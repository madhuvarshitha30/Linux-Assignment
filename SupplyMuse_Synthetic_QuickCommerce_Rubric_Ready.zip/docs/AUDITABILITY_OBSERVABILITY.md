# Auditability, observability, and explainability

## What is recorded

Every assistant workflow receives a UUID trace ID. The local SQLite WAL ledger at `backend/data/audit.db` records a completed event for each of these stages:

1. Intent routing by `RiskOrchestrator`.
2. Each routed specialist (`SupplierRiskAgent`, `DeliveryRiskAgent`, `InventoryRiskAgent`, and/or `DemandForecastAgent`).
3. Cross-risk synthesis.
4. Recommendation generation.
5. NVIDIA NIM rendering, or an explicit local-fallback readiness event.

An event contains UTC time, stage/component, status, duration, a SHA-256 input fingerprint, compact input/output metadata, method explanation, and an error type when applicable. The trace contains the total duration and outcome.

Raw questions, LLM prompts, API keys, and full evidence rows are intentionally not persisted. The ledger keeps question length and a one-way SHA-256 fingerprint for correlation without retaining user content. The evidence returned to the active user remains available in the response, but is not copied wholesale into the audit store.

## APIs

| Endpoint | Purpose |
| --- | --- |
| `GET /api/audit/traces?limit=50` | Recent workflow trace headers. |
| `GET /api/audit/traces/{trace_id}` | Ordered stage events for a trace, including method summaries and timing. |
| `GET /api/observability/metrics` | Success rate, average trace duration, stage counts/durations/errors. |
| `GET /api/explainability` | Dataset manifest fingerprints, risk taxonomy, forecast coefficients and audit policy. |
| `GET /api/explain/order/{order_id}` | Feature-level contribution card for an order-risk score. |

The Dashboard's **Audit & Observability** page presents the metrics, trace headers, data version, risk taxonomy and forecast coefficients. Each assistant response displays its trace ID and duration.

## Explainability policy

Each agent evidence object carries:

- source datasets;
- transformation/method;
- decision rule and relevant thresholds;
- inputs considered;
- limitations and human-review guardrails.

Order-level explanations expose individual score contributions. The forecast exposes its trained Ridge coefficients, training/validation windows, MAE/RMSE/MAPE, and data version. A risk or anomaly is always an investigation priority, not a causal conclusion or autonomous action.

## Operations notes

SQLite WAL supports local concurrent reads and short writes. This is suitable for the capstone/demo deployment. For a multi-instance production deployment, export the same event schema to a managed telemetry store, configure retention and access controls, and propagate the incoming `X-Request-ID` across services. Do not expose the audit endpoints publicly without authentication because trace metadata can be operationally sensitive.
