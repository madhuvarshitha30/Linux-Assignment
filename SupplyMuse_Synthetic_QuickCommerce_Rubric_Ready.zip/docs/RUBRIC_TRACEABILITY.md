# Rubric Traceability Matrix

| Rubric task | Implemented evidence |
|---|---|
| Task 1 — Data preparation & risk KB | Synthetic CSV tables, generator, data dictionary, quality endpoint, derived features, risk taxonomy |
| Task 2 — Risk detection & forecasting | Supplier scorecards, weighted risk model, MAD anomalies, inventory risk, affected products/orders, Ridge forecast, MAE/RMSE/MAPE |
| Task 3 — Multi-agent intelligence | Six specialist/consolidation agents, orchestrator routing, structured Evidence handoff, audit trace, provenance |
| Task 4 — Evaluation & application | Evaluation JSON, benchmark routing tests, forecast metrics, risk report, React supplier/inventory/forecast/anomaly/assistant/evidence screens |
| Task 5 — Architecture & demonstration | `ARCHITECTURE.pdf`, architecture/design docs, README, presentation guide, executable backend/frontend |

## Submission note

The frontend is retained as provided. The main implementation change is the replacement of legacy external supply-chain data with deterministic synthetic quick-commerce data and the backend/data documentation required to support that dataset.
