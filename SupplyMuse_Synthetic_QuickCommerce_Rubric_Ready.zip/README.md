# SupplyMuse

SupplyMuse is a full-stack AI-powered quick-commerce intelligence dashboard built around a deterministic synthetic demo dataset. It combines structured analytics, forecasting, supplier risk scoring, agent-based reasoning, and an explainable AI assistant for safe operational scenario exploration.

This project is a capstone-style implementation designed to demonstrate supply-chain risk intelligence for quick-commerce operations teams, planners, and risk managers.

## What the project is using

### Frontend
- React
- Vite
- Recharts
- Lucide icons
- Modern dashboard UI with role-based access flow

### Backend
- Python
- FastAPI
- Pandas / CSV-based data processing
- Local analytics modules for forecasting and risk scoring
- SQLite-backed audit and observability logging

### Intelligence layer
- Multi-agent orchestration for supply-chain reasoning
- LLM provider abstraction with OpenAI-compatible APIs
- Deterministic fallback responses when no API key is configured

### Data source
- **Only deterministic synthetic quick-commerce data**
- 12,000 order lines across 15 synthetic dark stores, 8 synthetic suppliers, and 30 synthetic SKUs
- 120 days of synthetic order history plus shipment, inventory, and daily-demand tables
- No Kaggle, Accenture, DataCo, customer PII, or real company records are required at runtime

## How SupplyMuse works

The system follows a practical decision-intelligence flow:

1. Data ingestion
   - A fixed-seed generator creates all synthetic quick-commerce records.
   - The generated CSV tables are the single source of truth for analytics and dashboard use.

2. Data preparation and quality layer
   - The backend validates schemas, timestamps, duplicates, missing values, and basic numeric outliers.
   - Data lineage, file hashes, generator seed, and processing metadata are available for auditability.

3. Risk and forecasting analytics
   - Supplier performance, late-delivery risk, inventory pressure, and forecast measures are calculated.
   - The analytics modules turn raw operational history into actionable signals.

4. Agent orchestration
   - Multiple specialist agents reason over supplier risk, delivery risk, inventory, and forecasts.
   - The orchestrator combines these outputs into a single evidence-based summary.

5. AI assistant layer
   - The assistant can answer operations questions using data-grounded reasoning.
   - If an LLM provider is configured, it may enrich responses with model-generated narrative.
   - If not, a deterministic local fallback still produces grounded answers.

6. Frontend dashboard
   - React displays the overview, risk tables, forecast areas, simulation tools, audit traces, and assistant views.
   - The dashboard acts as the operational control tower for planning and monitoring.

7. Audit and observability
   - Requests, workflow stages, and decisions are logged for traceability.
   - This supports explainability and operational review.

## Architecture overview

```text
Frontend (React + Vite)
        |
        v
FastAPI Backend
        |
        +--> Data Layer (CSV ingestion / normalization / quality checks)
        |
        +--> Analytics Layer (risk, forecast, anomaly, simulation)
        |
        +--> Agent Layer (supplier, delivery, inventory, insight agents)
        |
        +--> LLM Adapter (OpenAI-compatible / fallback provider)
        |
        +--> Audit + Observability Layer (trace logs, metrics, provenance)
```

## Repository structure

```text
quickcommerce_project/
├── backend/
│   ├── app/
│   │   ├── __init__.py
│   │   ├── agents.py
│   │   ├── analytics.py
│   │   ├── audit.py
│   │   ├── data.py
│   │   ├── llm.py
│   │   └── main.py
│   ├── data/
│   │   ├── DATA_DICTIONARY.md
│   │   ├── daily_demand.csv
│   │   ├── dark_stores.csv
│   │   ├── evaluation_report.json
│   │   ├── inbound_shipments.csv
│   │   ├── inventory.csv
│   │   ├── orders.csv
│   │   ├── products.csv
│   │   └── suppliers.csv
│   ├── generate_quickcommerce_data.py
│   ├── requirements.txt
│   ├── evaluate.py
│   └── START_BACKEND.bat
├── frontend/
│   ├── src/
│   ├── index.html
│   ├── package.json
│   ├── vite.config.js
│   └── START_FRONTEND.bat
├── docs/
│   ├── ARCHITECTURE.md
│   ├── AUDITABILITY_OBSERVABILITY.md
│   ├── DESIGN_AND_EVALUATION.md
│   ├── IMPLEMENTATION_GAPS.md
│   └── SUPPLY_CHAIN_SIMULATION.md
├── docker-compose.yml
├── README.md
└── .gitignore
```

## Key backend modules

### app/main.py
Main FastAPI application and route definitions. This is the entry point for the dashboards and assistant.

### app/data.py
Handles dataset loading, cleansing, summary metrics, and evidence generation.

### app/analytics.py
Contains risk calculations, anomaly detection, forecast logic, and scenario evaluation.

### app/agents.py
Defines the specialist agents and orchestrator that synthesize insights.

### app/llm.py
Abstracts LLM access and provides fallback behavior when no credentials are present.

### app/audit.py
Stores traces, execution metadata, and observability data.

## Frontend experience

The frontend is a productized control-tower dashboard that includes:
- Overview and KPI summary
- Delivery-risk and supplier views
- Inventory and forecast monitoring
- AI assistant for operational questions
- Agent orchestration visualization
- Simulation and risk-report modules
- Audit and observability screens
- Single-login flow with credential-based role selection

### Demo auth flow
The app uses a single login screen where the credentials determine the access role automatically.

- User login: `user@supplymuse.io` / `demo123`
- Admin login: `admin@supplymuse.io` / `admin123`

## Local setup

### 1. Backend

```powershell
cd backend
python -m venv .venv
.\.venv\Scripts\Activate.ps1
pip install -r requirements.txt
uvicorn app.main:app --reload --port 8000
```

API docs: http://localhost:8000/docs

### 2. Frontend

```powershell
cd frontend
npm install
npm run dev
```

Open: http://localhost:5173

## Environment / LLM configuration

The app supports OpenAI-compatible providers, but it can also run without an external LLM key.

Example backend environment settings:

```env
LLM_PROVIDER=nvidia
LLM_MODEL_OPENROUTER=openrouter/free
OPENROUTER_API_KEY=your_key_here
OPENAI_API_KEY=
NVIDIA_NIM_BASE_URL=https://integrate.api.nvidia.com/v1
LLM_MODEL_NVIDIA=openai/gpt-oss-20b
NVIDIA_API_KEY=
```

Provider options:
- OpenRouter
- OpenAI
- NVIDIA NIM

If no provider is configured, the app falls back to a deterministic local answer based on dataset-grounded analytics.

## API surface

Key endpoints include:
- `GET /api/health`
- `GET /api/summary`
- `GET /api/trends`
- `GET /api/risks`
- `GET /api/inventory`
- `GET /api/stock-summary`
- `GET /api/suppliers`
- `GET /api/forecast`
- `GET /api/anomalies`
- `GET /api/risk-report`
- `GET /api/llm/status`
- `GET /api/audit/traces`
- `GET /api/observability/metrics`
- `POST /api/assistant`

## Rubric alignment

The implementation is mapped to all five tasks in `docs/IMPLEMENTATION_GAPS.md`. The architecture submission artifact is `docs/ARCHITECTURE.pdf`, and the panel demo script is `presentation.md`.

## Data assumptions and limitations

The project uses deterministic synthetic quick-commerce data:
- supplier, order, shipment, product, dark-store, demand, and inventory values are generated locally
- `backend/generate_quickcommerce_data.py` is the canonical dataset generator
- generated inventory is a synthetic snapshot used for risk/scenario analysis, not a live inventory ledger
- high-risk supplier cases are deliberately included so the risk workflow can be demonstrated
- all values are for demonstration/testing and must not be interpreted as real operational facts

## Docker option

From the project root:

```bash
docker compose up --build
```

Then access:
- Frontend: http://localhost:5173
- Backend docs: http://localhost:8000/docs

## Why this project matters

SupplyMuse demonstrates how a practical supply-chain control tower can combine:
- operational analytics,
- forecasting and disruption simulation,
- specialist AI agents,
- explainable audit trails,
- and a clean user interface for decision-making.

This makes it a strong capstone project and also a realistic prototype for enterprise operational intelligence.
